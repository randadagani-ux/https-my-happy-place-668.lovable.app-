import type {
  AppState,
  CustomWorkouts,
  MuscleGroup,
  ScheduleDay,
  WorkoutItem,
} from "./types";

interface ExDef extends Omit<WorkoutItem, "id"> {
  id: string;
}

export const EXERCISES: ExDef[] = [
  {
    id: "goblet",
    nameEn: "Chair Squat / Goblet Squat",
    nameAr: "سكوات الكرسي / سكوات كوبل",
    muscle: "legs",
    unilateral: false,
    cueEn:
      "Hold the dumbbell at your chest. Sit back slowly onto a chair, pause, then press up through your heels.",
    cueAr:
      "أمسك الدبل عند صدرك. اجلس للخلف ببطء على كرسي، توقّف لحظة، ثم انطلق نحو الأعلى عبر كعبيك.",
    altEn: "Drop the dumbbell and use a regular sit-to-stand.",
    altAr: "اترك الدبل واستخدم الوقوف من الكرسي فقط.",
  },
  {
    id: "row1",
    nameEn: "One-Arm Dumbbell Row",
    nameAr: "سحب دبل بذراع واحدة",
    muscle: "back",
    unilateral: true,
    cueEn:
      "Support one hand on a chair, back flat. Row the dumbbell to your hip, squeeze the shoulder blade, lower slowly.",
    cueAr:
      "أسند يدًا على كرسي وظهرك مستقيم. اسحب الدبل نحو حوضك، اضغط لوح الكتف، وأنزله ببطء.",
    altEn: "Reduce the weight and keep the back straight.",
    altAr: "قلّل الوزن واحمِ ظهرك مستقيمًا.",
  },
  {
    id: "fpress",
    nameEn: "Dumbbell Floor Chest Press",
    nameAr: "ضغط صدر بالدبل على الأرض",
    muscle: "chest",
    unilateral: false,
    cueEn:
      "Lie on the floor, press the dumbbells up over your chest, then lower slowly until elbows touch the floor.",
    cueAr:
      "استلقِ على الأرض، ادفع الدبل نحو الأعلى فوق صدرك، وأنزله ببطء حتى تلمس مرفقاك الأرض.",
    altEn: "Use lighter dumbbells and a slower tempo.",
    altAr: "استخدم أوزانًا أخف وإيقاعًا أبطأ.",
  },
  {
    id: "rdl",
    nameEn: "Dumbbell Romanian Deadlift",
    nameAr: "الرفع الروماني بالدبل",
    muscle: "glutes",
    unilateral: false,
    cueEn:
      "Slight knee bend, push hips back, lower the dumbbells along your legs until you feel a hamstring stretch. Flat back.",
    cueAr:
      "ثنية خفيفة للركبتين، ادفع الورك للخلف، وأنزل الدبل على طول ساقيك حتى تشعر بشد. الظهر مستقيم.",
    altEn: "Use lighter weight and a shorter range of motion.",
    altAr: "استخدم وزنًا أخف ومدى حركة أقصر.",
  },
  {
    id: "spress",
    nameEn: "Seated Dumbbell Shoulder Press",
    nameAr: "ضغط أكتاف بالدبل جالسًا",
    muscle: "shoulders",
    unilateral: false,
    cueEn:
      "Sit with back support, press the dumbbells overhead. Skip this one if your shoulders feel tight.",
    cueAr:
      "اجلس بمسند ظهر، ادفع الدبل فوق رأسك. تخطَّ هذا التمرين إذا كانت أكتافك متوترة.",
    altEn: "Do floor chest press instead, or reduce the weight.",
    altAr: "أدِّ ضغط الصدر على الأرض بدلًا منه أو قلّل الوزن.",
  },
  {
    id: "calf",
    nameEn: "Supported Standing Calf Raise",
    nameAr: "رفع السمانة واقفًا",
    muscle: "calves",
    unilateral: false,
    cueEn:
      "Hold a support for balance, rise onto your toes, pause at the top, then lower slowly.",
    cueAr: "تمسك ما يثبّت توازنك، اصعد على أطراف قدميك، توقّف في الأعلى، وأنزل ببطء.",
    altEn: "Do it seated with knees bent to unload the calves.",
    altAr: "أدِّه جالسًا والركبتان مثنيتان لتخفيف الشد.",
  },
  {
    id: "stt",
    nameEn: "Sit-to-Stand / Chair Squat",
    nameAr: "الوقوف من الكرسي",
    muscle: "legs",
    unilateral: false,
    cueEn:
      "From a chair, stand up fully without using your hands, then sit back down under control.",
    cueAr: "من الكرسي، اقفز بالكامل دون استخدام يديك، ثم عد للجلوس ببطء وتحكّم.",
    altEn: "Use your hands lightly for support if needed.",
    altAr: "استخدم يديك برفعة خفيفة إن احتجت.",
  },
  {
    id: "curl",
    nameEn: "Dumbbell Biceps Curl",
    nameAr: "رنّة البايسبس بالدبل",
    muscle: "arms",
    unilateral: false,
    cueEn: "Elbows fixed at your sides, curl both dumbbells up, then lower under control.",
    cueAr: "ثبّت المرفقين على جانبيك، ارفع الدبل، وأنزله ببطء وتحكّم.",
    altEn: "Reduce the weight and keep the elbows still.",
    altAr: "قلّل الوزن وثبّت المرفقين.",
  },
];

export const MUSCLE_LABELS: Record<MuscleGroup, { en: string; ar: string }> = {
  legs: { en: "Legs", ar: "الأرجل" },
  glutes: { en: "Glutes & Hamstrings", ar: "الأرداف والبايت" },
  back: { en: "Back", ar: "الظهر" },
  chest: { en: "Chest", ar: "الصدر" },
  shoulders: { en: "Shoulders", ar: "الأكتاف" },
  arms: { en: "Arms", ar: "الذراعان" },
  calves: { en: "Calves", ar: "السمانة" },
};

export function itemFromLibId(id: string): WorkoutItem | null {
  const lib = EXERCISES.find((e) => e.id === id);
  if (!lib) return null;
  return { ...lib, libId: lib.id };
}

export const DEFAULT_WORKOUTS: CustomWorkouts = {
  A: ["goblet", "row1", "fpress", "rdl", "spress", "calf"]
    .map(itemFromLibId)
    .filter((x): x is WorkoutItem => x !== null),
  B: ["stt", "rdl", "row1", "fpress", "spress", "curl", "calf"]
    .map(itemFromLibId)
    .filter((x): x is WorkoutItem => x !== null),
};

// Saturday first, matching the program.
export const DEFAULT_SCHEDULE: ScheduleDay[] = [
  { key: "sat", dayIndex: 6, type: "A", enabled: true },
  { key: "sun", dayIndex: 0, type: "walk", enabled: true },
  { key: "mon", dayIndex: 1, type: "B", enabled: true },
  { key: "tue", dayIndex: 2, type: "recovery", enabled: true },
  { key: "wed", dayIndex: 3, type: "A", enabled: true, week3PlusOnly: true },
  { key: "thu", dayIndex: 4, type: "walk", enabled: true },
  { key: "fri", dayIndex: 5, type: "rest", enabled: true },
];

export interface PlanPhase {
  phaseEn: string;
  phaseAr: string;
  focusEn: string;
  focusAr: string;
}

const PHASES: Record<string, PlanPhase> = {
  foundation: {
    phaseEn: "Foundation",
    phaseAr: "التأسيس",
    focusEn: "Learn the movements with light, comfortable weights. 1–2 sets of 8–10 reps.",
    focusAr: "تعلّم الحركات بأوزان خفيفة ومريحة. 1–2 مجموعات من 8–10 تكرارات.",
  },
  building: {
    phaseEn: "Building",
    phaseAr: "البناء",
    focusEn: "2–3 sets of 8–12 reps. Add the third strength day if recovery is good.",
    focusAr: "2–3 مجموعات من 8–12 تكرار. أضف يوم القوة الثالث إذا كان الاستشفاء جيدًا.",
  },
  progression: {
    phaseEn: "Progression",
    phaseAr: "التقدم",
    focusEn: "Keep 2–3 × 8–12. Grow reps within the range first, mind your form.",
    focusAr: "حافظ على 2–3 × 8–12. زد التكرارات داخل النطاق أولًا مع الحفاظ على الأداء.",
  },
  strength: {
    phaseEn: "Strength",
    phaseAr: "القوة",
    focusEn: "Gradually increase resistance when the top of the range feels easy (RPE ≤ 7).",
    focusAr: "زد المقاومة تدريجيًا عندما يصبح أعلى النطاق سهلًا (RPE ≤ 7).",
  },
  peak: {
    phaseEn: "Peak",
    phaseAr: "الذروة",
    focusEn: "Heaviest phase. Prioritize full rest days and quality sleep.",
    focusAr: "المرحلة الأثقل. أولِ أيام الراحة الكاملة ونومًا جيدًا.",
  },
};

export function phaseForWeek(week: number): PlanPhase {
  if (week <= 2) return PHASES.foundation;
  if (week <= 4) return PHASES.building;
  if (week <= 6) return PHASES.progression;
  if (week <= 9) return PHASES.strength;
  return PHASES.peak;
}

export function repRangeForWeek(week: number): [number, number] {
  return week <= 2 ? [8, 10] : [8, 12];
}

export function defaultState(): AppState {
  const d = new Date();
  const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return {
    version: 1,
    onboarded: false,
    profile: {
      name: "",
      goal: "both",
      startWeightKg: 80,
      targetWeightKg: 72,
      heightCm: 170,
      startDate: iso,
    },
    settings: {
      lang: "ar",
      calorieTarget: 1800,
      proteinTarget: 110,
      walkGoalMin: 150,
      restSeconds: 90,
      setsPerExercise: 2,
      weightConvention: "per",
    },
    meals: [],
    weights: [],
    measurements: [],
    sleep: [],
    treadmill: [],
    sessions: [],
    customWorkouts: DEFAULT_WORKOUTS,
    schedule: DEFAULT_SCHEDULE,
    approvedProgression: {},
  };
}
