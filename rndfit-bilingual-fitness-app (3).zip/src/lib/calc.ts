import type {
  AppState,
  MuscleGroup,
  ScheduleDay,
  SetRecord,
  WorkoutItem,
  WorkoutSession,
} from "./types";
import { repRangeForWeek } from "./data";

export function uid(): string {
  return (
    Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-5)
  );
}

export function toISO(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function todayISO(): string {
  return toISO(new Date());
}

export function addDaysISO(iso: string, n: number): string {
  const d = new Date(`${iso}T12:00:00`);
  d.setDate(d.getDate() + n);
  return toISO(d);
}

/** Saturday-based start of week. */
export function startOfWeekSat(iso: string): string {
  const d = new Date(`${iso}T12:00:00`);
  const offset = (d.getDay() - 6 + 7) % 7;
  return addDaysISO(iso, -offset);
}

export function daysDiffISO(from: string, to: string): number {
  const a = new Date(`${from}T12:00:00`).getTime();
  const b = new Date(`${to}T12:00:00`).getTime();
  return Math.round((b - a) / 86400000);
}

export function programWeek(startDate: string, today = todayISO()): number {
  const diff = daysDiffISO(startDate, today);
  if (diff < 0) return 1;
  return Math.min(12, Math.floor(diff / 7) + 1);
}

export function itemsById(state: AppState): Map<string, WorkoutItem> {
  const map = new Map<string, WorkoutItem>();
  for (const it of [...state.customWorkouts.A, ...state.customWorkouts.B]) {
    map.set(it.id, it);
  }
  return map;
}

export function allUniqueItems(state: AppState): WorkoutItem[] {
  return [...itemsById(state).values()];
}

export function setRepsTotal(set: SetRecord): number {
  if (set.repsLeft != null || set.repsRight != null) {
    return (set.repsLeft ?? 0) + (set.repsRight ?? 0);
  }
  return set.reps;
}

/**
 * Volume convention: weight × reps × (×2 when two hands are loaded).
 * The recorded weight follows the user's weightConvention setting.
 */
export function setVolume(set: SetRecord, item: WorkoutItem | undefined): number {
  const factor = item && item.unilateral ? 1 : 2;
  return set.weightKg * setRepsTotal(set) * factor;
}

export interface SessionStats {
  setsDone: number;
  reps: number;
  volume: number;
  durationMin: number;
}

export function sessionStats(
  session: WorkoutSession,
  items: Map<string, WorkoutItem>
): SessionStats {
  let setsDone = 0;
  let reps = 0;
  let volume = 0;
  for (const set of session.sets) {
    if (!set.completed) continue;
    setsDone++;
    reps += setRepsTotal(set);
    volume += setVolume(set, items.get(set.exerciseInstanceId));
  }
  let durationMin = 0;
  if (session.startedAt && session.finishedAt) {
    durationMin = Math.max(
      1,
      Math.round((new Date(session.finishedAt).getTime() - new Date(session.startedAt).getTime()) / 60000)
    );
  }
  return { setsDone, reps, volume, durationMin };
}

export function completedSessionsIn(
  sessions: WorkoutSession[],
  from: string,
  to: string
): WorkoutSession[] {
  return sessions
    .filter((s) => s.status === "completed" && s.date >= from && s.date <= to)
    .sort((a, b) => a.date.localeCompare(b.date));
}

export function lastCompletedSetFor(
  sessions: WorkoutSession[],
  itemId: string,
  beforeDate?: string
): SetRecord | null {
  let best: SetRecord | null = null;
  for (const s of sessions) {
    if (s.status !== "completed") continue;
    if (beforeDate && s.date > beforeDate) continue;
    for (const set of s.sets) {
      if (set.exerciseInstanceId !== itemId || !set.completed) continue;
      if (!best || set.timestamp >= best.timestamp) best = set;
    }
  }
  return best;
}

export interface ExercisePoint {
  date: string;
  weight: number; // top (max) recorded weight that session
  topReps: number; // max reps in a single set
  setsDone: number;
  volume: number;
}

export function exerciseSeries(
  sessions: WorkoutSession[],
  items: Map<string, WorkoutItem>,
  itemId: string
): ExercisePoint[] {
  const points: ExercisePoint[] = [];
  for (const s of completedSessionsIn(sessions, "0000-00-00", "9999-99-99")) {
    const sets = s.sets.filter((x) => x.exerciseInstanceId === itemId && x.completed);
    if (sets.length === 0) continue;
    let weight = 0;
    let topReps = 0;
    let volume = 0;
    for (const set of sets) {
      weight = Math.max(weight, set.weightKg);
      topReps = Math.max(topReps, setRepsTotal(set));
      volume += setVolume(set, items.get(itemId));
    }
    points.push({ date: s.date, weight, topReps, setsDone: sets.length, volume });
  }
  return points;
}

export function bestSetFor(
  sessions: WorkoutSession[],
  itemId: string
): { set: SetRecord; date: string } | null {
  let best: { set: SetRecord; date: string; vol: number } | null = null;
  for (const s of sessions) {
    if (s.status !== "completed") continue;
    for (const set of s.sets) {
      if (set.exerciseInstanceId !== itemId || !set.completed) continue;
      const vol = set.weightKg * setRepsTotal(set);
      if (!best || vol > best.vol || (vol === best.vol && set.weightKg > best.set.weightKg)) {
        best = { set, date: s.date, vol };
      }
    }
  }
  return best ? { set: best.set, date: best.date } : null;
}

export interface PrevDelta {
  dw: number;
  dr: number;
}

/** Compare the latest logged session vs the previous one for an exercise. */
export function prevDeltas(
  sessions: WorkoutSession[],
  itemId: string
): PrevDelta | null {
  const series = exerciseSeries(sessions, new Map(), itemId);
  if (series.length < 2) return null;
  const last = series[series.length - 1];
  const prev = series[series.length - 2];
  return { dw: +(last.weight - prev.weight).toFixed(1), dr: last.topReps - prev.topReps };
}

/** Strength days planned for a given program week. */
export function plannedStrengthDays(schedule: ScheduleDay[], week: number): ScheduleDay[] {
  return schedule.filter(
    (d) =>
      d.enabled &&
      (d.type === "A" || d.type === "B") &&
      (!d.week3PlusOnly || week >= 3)
  );
}

export function dateForWeekDay(weekStartSat: string, day: ScheduleDay): string {
  const offset = (day.dayIndex - 6 + 7) % 7;
  return addDaysISO(weekStartSat, offset);
}

export function sessionForDay(
  sessions: WorkoutSession[],
  weekStartSat: string,
  day: ScheduleDay
): WorkoutSession | null {
  if (day.type !== "A" && day.type !== "B") return null;
  const date = dateForWeekDay(weekStartSat, day);
  // Prefer the session on this exact day, else any same-plan session this week.
  let fallback: WorkoutSession | null = null;
  for (const s of sessions) {
    if (s.planId !== day.type) continue;
    const inWeek = s.date >= weekStartSat && s.date < addDaysISO(weekStartSat, 7);
    if (s.date === date) return s;
    if (inWeek && !fallback) fallback = s;
  }
  return fallback;
}

export function weekCompletion(
  sessions: WorkoutSession[],
  schedule: ScheduleDay[],
  weekStartSat: string,
  week: number
): { done: number; planned: number; pct: number } {
  const planned = plannedStrengthDays(schedule, week);
  let done = 0;
  for (const day of planned) {
    const s = sessionForDay(sessions, weekStartSat, day);
    if (s && s.status === "completed") done++;
  }
  return {
    done,
    planned: planned.length,
    pct: planned.length === 0 ? 0 : Math.round((done / planned.length) * 100),
  };
}

export function volumeBetween(
  sessions: WorkoutSession[],
  items: Map<string, WorkoutItem>,
  from: string,
  to: string
): { volume: number; sets: number; reps: number; sessions: number } {
  let volume = 0;
  let sets = 0;
  let reps = 0;
  let n = 0;
  for (const s of completedSessionsIn(sessions, from, to)) {
    n++;
    const st = sessionStats(s, items);
    volume += st.volume;
    sets += st.setsDone;
    reps += st.reps;
  }
  return { volume, sets, reps, sessions: n };
}

export function muscleGroupSets(
  sessions: WorkoutSession[],
  items: Map<string, WorkoutItem>,
  from: string,
  to: string
): { group: MuscleGroup; count: number }[] {
  const acc = new Map<MuscleGroup, number>();
  for (const s of completedSessionsIn(sessions, from, to)) {
    for (const set of s.sets) {
      if (!set.completed) continue;
      const item = items.get(set.exerciseInstanceId);
      if (!item) continue;
      acc.set(item.muscle, (acc.get(item.muscle) ?? 0) + 1);
    }
  }
  return [...acc.entries()]
    .map(([group, count]) => ({ group, count }))
    .sort((a, b) => b.count - a.count);
}

export interface Suggestion {
  itemId: string;
  kind: "weight" | "reps" | "hold";
  weightKg?: number;
  reps?: number;
}

/**
 * Transparent progression rule: all prescribed sets at the top of the rep
 * range with manageable effort (RPE ≤ 7) in two consecutive sessions.
 */
export function overloadSuggestions(state: AppState): Suggestion[] {
  const week = programWeek(state.profile.startDate);
  const [, hi] = repRangeForWeek(week);
  const setsP = Math.max(1, state.settings.setsPerExercise);
  const out: Suggestion[] = [];

  for (const item of allUniqueItems(state)) {
    const withSets = state.sessions
      .filter(
        (s) =>
          s.status === "completed" &&
          s.sets.some((x) => x.exerciseInstanceId === item.id && x.completed)
      )
      .sort((a, b) => b.date.localeCompare(a.date));
    if (withSets.length < 2) continue;

    const check = (s: WorkoutSession): boolean => {
      const sets = s.sets.filter(
        (x) => x.exerciseInstanceId === item.id && x.completed
      );
      const top = Math.max(...sets.map((x) => setRepsTotal(x)));
      const rpeAvg = sets.reduce((a, x) => a + x.rpe, 0) / sets.length;
      return sets.length >= setsP && top >= hi && rpeAvg <= 7;
    };

    if (!check(withSets[0]) || !check(withSets[1])) continue;

    const last = lastCompletedSetFor(state.sessions, item.id);
    const w = last ? last.weightKg : 0;
    if (w <= 0) out.push({ itemId: item.id, kind: "reps", reps: 1 });
    else if (w >= 10) out.push({ itemId: item.id, kind: "hold" });
    else out.push({ itemId: item.id, kind: "weight", weightKg: +(w + 0.5).toFixed(1) });
  }
  return out;
}

export function buildCsv(state: AppState): string {
  const items = itemsById(state);
  const rows: string[] = [
    "date,plan,exercise_en,exercise_ar,set,weight_kg,reps,reps_left,reps_right,target_reps,rest_seconds,rpe,completed,notes",
  ];
  const all = state.sessions
    .filter((s) => s.sets.length > 0)
    .flatMap((s) => s.sets.map((set) => ({ s, set })))
    .sort((a, b) => a.set.timestamp.localeCompare(b.set.timestamp));
  for (const { s, set } of all) {
    const item = items.get(set.exerciseInstanceId);
    const notes = (set.notes || "").replace(/"/g, "'");
    rows.push(
      [
        s.date,
        s.planId,
        `"${(item?.nameEn ?? "").replace(/"/g, "'")}"`,
        `"${(item?.nameAr ?? "").replace(/"/g, "'")}"`,
        set.setNumber,
        set.weightKg,
        set.reps,
        set.repsLeft ?? "",
        set.repsRight ?? "",
        set.targetReps,
        set.restSeconds,
        set.rpe,
        set.completed ? "yes" : "no",
        `"${notes}"`,
      ].join(",")
    );
  }
  return rows.join("\n");
}

export function durationFmt(ms: number): string {
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}
