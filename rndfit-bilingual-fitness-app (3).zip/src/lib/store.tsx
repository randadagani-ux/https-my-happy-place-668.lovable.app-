"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type {
  AppState,
  MealEntry,
  MeasurementEntry,
  Profile,
  Readiness,
  ScheduleDay,
  Settings,
  SetRecord,
  SleepEntry,
  TreadmillEntry,
  WorkoutItem,
  WorkoutSession,
} from "./types";
import { defaultState, repRangeForWeek } from "./data";
import { makeT, type Lang, fmtDate, fmtInt, fmtNum, fmtWeekday } from "./i18n";
import { programWeek, todayISO, uid } from "./calc";

const KEY = "rndfit.data.v1";

function loadState(): AppState {
  if (typeof window === "undefined") return defaultState();
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw) as AppState;
      if (
        s &&
        s.version === 1 &&
        Array.isArray(s.sessions) &&
        Array.isArray(s.schedule) &&
        s.settings &&
        s.profile &&
        s.customWorkouts
      ) {
        return s;
      }
    }
  } catch {
    // fall through to defaults
  }
  return defaultState();
}

interface Prescription {
  sets: number;
  lo: number;
  hi: number;
  rest: number;
}

interface AppCtx {
  state: AppState;
  ready: boolean;
  t: (key: string, vars?: Record<string, string | number>) => string;
  lang: Lang;
  dir: "rtl" | "ltr";
  week: number;
  prescription: Prescription;
  fmtNum: (n: number, frac?: number) => string;
  fmtInt: (n: number) => string;
  fmtDate: (iso: string, style?: "short" | "medium") => string;
  fmtWeekday: (iso: string) => string;
  setLang: (l: Lang) => void;
  updateSettings: (p: Partial<Settings>) => void;
  updateProfile: (p: Partial<Profile>) => void;
  completeOnboarding: (profile: Profile) => void;
  addMeal: (m: Omit<MealEntry, "id">) => void;
  removeMeal: (id: string) => void;
  addWeight: (date: string, kg: number) => void;
  removeWeight: (id: string) => void;
  addMeasurement: (m: Omit<MeasurementEntry, "id">) => void;
  removeMeasurement: (id: string) => void;
  addSleep: (s: Omit<SleepEntry, "id">) => void;
  removeSleep: (id: string) => void;
  addTreadmill: (t: Omit<TreadmillEntry, "id">) => void;
  removeTreadmill: (id: string) => void;
  findInProgress: (planId: "A" | "B") => WorkoutSession | null;
  startSession: (planId: "A" | "B", readiness: Readiness | null, reduced: boolean) => string;
  addSet: (sessionId: string, rec: Omit<SetRecord, "id" | "timestamp">) => void;
  updateSet: (sessionId: string, setId: string, patch: Partial<SetRecord>) => void;
  removeSet: (sessionId: string, setId: string) => void;
  finishSession: (id: string) => void;
  addSkippedSession: (planId: "A" | "B", dateISO: string) => void;
  setScheduleDay: (key: string, patch: Partial<ScheduleDay>) => void;
  setWorkoutItems: (planId: "A" | "B", items: WorkoutItem[]) => void;
  approveProgression: (itemId: string, patch: { weightKg?: number; targetReps?: number }) => void;
  exportData: () => string;
  importData: (json: string) => boolean;
  resetAll: () => void;
}

const Ctx = createContext<AppCtx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(defaultState());
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setState(loadState());
    setReady(true);
  }, []);

  const lang = state.settings.lang;
  const dir: "rtl" | "ltr" = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      // storage full / unavailable — ignore
    }
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
    document.title = "RNDFIT — Stronger Every Day";
  }, [state, ready, lang, dir]);

  const mutate = useCallback((fn: (s: AppState) => AppState) => {
    setState((s) => fn(s));
  }, []);

  const t = useMemo(() => makeT(lang), [lang]);
  const week = programWeek(state.profile.startDate);
  const [lo, hi] = repRangeForWeek(week);
  const prescription: Prescription = {
    sets: Math.max(1, Math.min(3, state.settings.setsPerExercise)),
    lo,
    hi,
    rest: state.settings.restSeconds,
  };

  const value: AppCtx = {
    state,
    ready,
    t,
    lang,
    dir,
    week,
    prescription,
    fmtNum: useCallback((n: number, frac = 1) => fmtNum(lang, n, frac), [lang]),
    fmtInt: useCallback((n: number) => fmtInt(lang, n), [lang]),
    fmtDate: useCallback((iso: string, style: "short" | "medium" = "short") => fmtDate(lang, iso, style), [lang]),
    fmtWeekday: useCallback((iso: string) => fmtWeekday(lang, iso), [lang]),

    setLang: (l) =>
      mutate((s) => ({ ...s, settings: { ...s.settings, lang: l } })),

    updateSettings: (p) =>
      mutate((s) => ({ ...s, settings: { ...s.settings, ...p } })),

    updateProfile: (p) =>
      mutate((s) => ({ ...s, profile: { ...s.profile, ...p } })),

    completeOnboarding: (profile) =>
      mutate((s) => {
        const weights = s.weights.some((w) => w.date === profile.startDate)
          ? s.weights.map((w) =>
              w.date === profile.startDate ? { ...w, weightKg: profile.startWeightKg } : w
            )
          : [...s.weights, { id: uid(), date: profile.startDate, weightKg: profile.startWeightKg }];
        return { ...s, onboarded: true, profile, weights };
      }),

    addMeal: (m) => mutate((s) => ({ ...s, meals: [...s.meals, { ...m, id: uid() }] })),
    removeMeal: (id) => mutate((s) => ({ ...s, meals: s.meals.filter((m) => m.id !== id) })),

    addWeight: (date, kg) =>
      mutate((s) => {
        const existing = s.weights.find((w) => w.date === date);
        return {
          ...s,
          weights: existing
            ? s.weights.map((w) => (w.date === date ? { ...w, weightKg: kg } : w))
            : [...s.weights, { id: uid(), date, weightKg: kg }],
        };
      }),
    removeWeight: (id) => mutate((s) => ({ ...s, weights: s.weights.filter((w) => w.id !== id) })),

    addMeasurement: (m) => mutate((s) => ({ ...s, measurements: [...s.measurements, { ...m, id: uid() }] })),
    removeMeasurement: (id) =>
      mutate((s) => ({ ...s, measurements: s.measurements.filter((m) => m.id !== id) })),

    addSleep: (sl) =>
      mutate((s) => {
        const existing = s.sleep.find((x) => x.date === sl.date);
        return {
          ...s,
          sleep: existing
            ? s.sleep.map((x) => (x.date === sl.date ? { ...x, hours: sl.hours, quality: sl.quality } : x))
            : [...s.sleep, { ...sl, id: uid() }],
        };
      }),
    removeSleep: (id) => mutate((s) => ({ ...s, sleep: s.sleep.filter((x) => x.id !== id) })),

    addTreadmill: (tm) => mutate((s) => ({ ...s, treadmill: [...s.treadmill, { ...tm, id: uid() }] })),
    removeTreadmill: (id) =>
      mutate((s) => ({ ...s, treadmill: s.treadmill.filter((x) => x.id !== id) })),

    findInProgress: (planId) =>
      state.sessions.find(
        (s) => s.status === "in-progress" && s.planId === planId && s.date === todayISO()
      ) ?? null,

    startSession: (planId, readiness, reduced) => {
      const id = uid();
      const today = todayISO();
      mutate((s) => {
        const sessions = s.sessions.filter(
          (x) => !(x.status === "in-progress" && x.planId === planId)
        );
        const session: WorkoutSession = {
          id,
          date: today,
          planId,
          status: "in-progress",
          startedAt: new Date().toISOString(),
          finishedAt: null,
          readiness,
          reduced,
          notes: "",
          sets: [],
        };
        return { ...s, sessions: [...sessions, session] };
      });
      return id;
    },

    addSet: (sessionId, rec) =>
      mutate((s) => ({
        ...s,
        sessions: s.sessions.map((x) =>
          x.id === sessionId ? { ...x, sets: [...x.sets, { ...rec, id: uid(), timestamp: new Date().toISOString() }] } : x
        ),
      })),

    updateSet: (sessionId, setId, patch) =>
      mutate((s) => ({
        ...s,
        sessions: s.sessions.map((x) =>
          x.id === sessionId
            ? { ...x, sets: x.sets.map((st) => (st.id === setId ? { ...st, ...patch } : st)) }
            : x
        ),
      })),

    removeSet: (sessionId, setId) =>
      mutate((s) => ({
        ...s,
        sessions: s.sessions.map((x) =>
          x.id === sessionId ? { ...x, sets: x.sets.filter((st) => st.id !== setId) } : x
        ),
      })),

    finishSession: (id) =>
      mutate((s) => ({
        ...s,
        sessions: s.sessions.map((x) =>
          x.id === id ? { ...x, status: "completed", finishedAt: new Date().toISOString() } : x
        ),
      })),

    addSkippedSession: (planId, dateISO) =>
      mutate((s) => {
        const existing = s.sessions.find(
          (x) => x.planId === planId && x.date === dateISO && x.status !== "in-progress"
        );
        if (existing) {
          return {
            ...s,
            sessions: s.sessions.map((x) => (x.id === existing.id ? { ...x, status: "skipped" } : x)),
          };
        }
        return {
          ...s,
          sessions: [
            ...s.sessions,
            {
              id: uid(),
              date: dateISO,
              planId,
              status: "skipped",
              startedAt: null,
              finishedAt: null,
              readiness: null,
              reduced: false,
              notes: "",
              sets: [],
            },
          ],
        };
      }),

    setScheduleDay: (key, patch) =>
      mutate((s) => ({
        ...s,
        schedule: s.schedule.map((d) => (d.key === key ? { ...d, ...patch } : d)),
      })),

    setWorkoutItems: (planId, items) =>
      mutate((s) => ({
        ...s,
        customWorkouts: { ...s.customWorkouts, [planId]: items },
      })),

    approveProgression: (itemId, patch) =>
      mutate((s) => ({
        ...s,
        approvedProgression: {
          ...s.approvedProgression,
          [itemId]: { ...s.approvedProgression[itemId], ...patch },
        },
      })),

    exportData: () => JSON.stringify(state, null, 2),

    importData: (json) => {
      try {
        const s = JSON.parse(json) as AppState;
        if (
          !s ||
          s.version !== 1 ||
          !Array.isArray(s.sessions) ||
          !Array.isArray(s.schedule) ||
          !s.settings ||
          !s.profile ||
          !s.customWorkouts
        ) {
          return false;
        }
        setState(s);
        return true;
      } catch {
        return false;
      }
    },

    resetAll: () => {
      try {
        window.localStorage.removeItem(KEY);
      } catch {
        // ignore
      }
      setState(defaultState());
    },
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
