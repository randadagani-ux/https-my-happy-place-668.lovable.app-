import type { Lang } from "./i18n";

export type Goal = "lose" | "build" | "both";

export interface Profile {
  name: string;
  goal: Goal;
  startWeightKg: number;
  targetWeightKg: number;
  heightCm: number;
  startDate: string; // ISO yyyy-mm-dd
}

export interface Settings {
  lang: Lang;
  calorieTarget: number;
  proteinTarget: number;
  walkGoalMin: number;
  restSeconds: number;
  setsPerExercise: number; // 1..3
  weightConvention: "per" | "combined";
}

export type MealCategory = "breakfast" | "lunch" | "dinner" | "snack";

export interface MealEntry {
  id: string;
  date: string;
  category: MealCategory;
  name: string;
  calories: number;
  proteinG: number;
}

export interface WeightEntry {
  id: string;
  date: string;
  weightKg: number;
}

export interface MeasurementEntry {
  id: string;
  date: string;
  chestCm: number | null;
  waistCm: number | null;
  hipCm: number | null;
  armCm: number | null;
  thighCm: number | null;
}

export interface SleepEntry {
  id: string;
  date: string;
  hours: number;
  quality: number; // 1..5
}

export interface TreadmillEntry {
  id: string;
  date: string;
  minutes: number;
  km: number | null;
}

export type MuscleGroup = "legs" | "glutes" | "back" | "chest" | "shoulders" | "arms" | "calves";

export interface WorkoutItem {
  id: string; // stable instance id (lib id for library exercises)
  libId?: string;
  nameEn: string;
  nameAr: string;
  muscle: MuscleGroup;
  unilateral: boolean;
  cueEn: string;
  cueAr: string;
  altEn?: string;
  altAr?: string;
}

export interface CustomWorkouts {
  A: WorkoutItem[];
  B: WorkoutItem[];
}

export interface Readiness {
  sleep: number; // 1..5
  energy: number; // 1..5
  soreness: number; // 1..5 (higher = more sore)
}

export interface SetRecord {
  id: string;
  exerciseInstanceId: string;
  setNumber: number;
  weightKg: number;
  reps: number;
  repsLeft: number | null;
  repsRight: number | null;
  targetReps: number;
  restSeconds: number;
  rpe: number; // 1..10
  notes: string;
  completed: boolean;
  timestamp: string; // full ISO
}

export type SessionStatus = "completed" | "skipped" | "in-progress";

export interface WorkoutSession {
  id: string;
  date: string; // yyyy-mm-dd
  planId: "A" | "B";
  status: SessionStatus;
  startedAt: string | null;
  finishedAt: string | null;
  readiness: Readiness | null;
  reduced: boolean;
  notes: string;
  sets: SetRecord[];
}

export type ScheduleDayType = "A" | "B" | "walk" | "recovery" | "rest";

export interface ScheduleDay {
  key: string;
  dayIndex: number; // JS Date.getDay(): 0=Sun..6=Sat
  type: ScheduleDayType;
  enabled: boolean;
  week3PlusOnly?: boolean;
}

export interface ApprovedProgression {
  weightKg?: number;
  targetReps?: number;
}

export interface AppState {
  version: 1;
  onboarded: boolean;
  profile: Profile;
  settings: Settings;
  meals: MealEntry[];
  weights: WeightEntry[];
  measurements: MeasurementEntry[];
  sleep: SleepEntry[];
  treadmill: TreadmillEntry[];
  sessions: WorkoutSession[];
  customWorkouts: CustomWorkouts;
  schedule: ScheduleDay[];
  approvedProgression: Record<string, ApprovedProgression>;
}
