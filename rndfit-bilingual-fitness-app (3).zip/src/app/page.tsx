"use client";

import { useEffect, useState } from "react";
import { AppProvider, useApp } from "@/lib/store";
import type { Goal } from "@/lib/types";
import type { Lang } from "@/lib/i18n";
import { todayISO } from "@/lib/calc";
import { Btn, Card, DateInput, Field, Icon, Logo, NumInput, Segmented, TextInput, Wordmark, type IconName } from "@/components/ui";
import Home from "@/screens/Home";
import Workouts from "@/screens/Workouts";
import Nutrition from "@/screens/Nutrition";
import Progress from "@/screens/Progress";
import More from "@/screens/More";
import Schedule from "@/screens/Schedule";
import LiveWorkout from "@/screens/LiveWorkout";
import Reports from "@/screens/Reports";

function useRoute() {
  const [hash, setHash] = useState<string>(() =>
    typeof window === "undefined" ? "" : window.location.hash
  );
  useEffect(() => {
    const on = () => {
      setHash(window.location.hash);
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const parts = hash.replace(/^#\//, "").split("/");
  const name = parts[0] || "home";
  return { name, param: parts[1] };
}

const go = (screen: string) => {
  window.location.hash = `#/${screen}`;
};

const NAV: { screen: string; icon: IconName; labelKey: string }[] = [
  { screen: "home", icon: "home", labelKey: "navHome" },
  { screen: "workouts", icon: "dumbbell", labelKey: "navWorkouts" },
  { screen: "nutrition", icon: "utensils", labelKey: "navNutrition" },
  { screen: "progress", icon: "chart", labelKey: "navProgress" },
  { screen: "more", icon: "more", labelKey: "navMore" },
];

function BottomNav({ active }: { active: string }) {
  const { t } = useApp();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-ink/92 backdrop-blur-md">
      <div className="mx-auto grid max-w-2xl grid-cols-5 px-2 pb-[max(env(safe-area-inset-bottom),8px)] pt-2">
        {NAV.map((n) => {
          const isActive = active === n.screen;
          return (
            <button
              key={n.screen}
              onClick={() => go(n.screen)}
              className={`flex flex-col items-center gap-1 rounded-xl py-1.5 transition ${
                isActive ? "text-flame" : "text-mist hover:text-snow"
              }`}
            >
              <Icon name={n.icon} size={21} strokeWidth={isActive ? 2.1 : 1.7} />
              <span className="text-[9.5px] font-semibold">{t(n.labelKey)}</span>
              <span className={`h-1 w-6 rounded-full ${isActive ? "bg-flame" : "bg-transparent"}`} />
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function Header({ sub }: { sub?: string }) {
  const { t, lang, setLang } = useApp();
  return (
    <header className="mb-3 flex items-center justify-between">
      {sub ? (
        <button
          onClick={() => go("workouts")}
          className="grid size-9 place-items-center rounded-xl border border-line bg-surface text-snow active:scale-95"
          aria-label={t("back")}
        >
          <Icon name="chevL" size={18} className="rtl:scale-x-[-1]" />
        </button>
      ) : (
        <div className="flex items-center gap-2">
          <Logo size={38} />
          <Wordmark className="text-2xl" />
        </div>
      )}
      <button
        onClick={() => setLang((lang === "ar" ? "en" : "ar") as Lang)}
        className="rounded-xl border border-line bg-surface px-3 py-2 text-xs font-bold text-flame active:scale-95"
        aria-label={t("language")}
      >
        {lang === "ar" ? "EN" : "ع"}
      </button>
    </header>
  );
}

function Onboarding() {
  const { t, lang, setLang, completeOnboarding } = useApp();
  const [name, setName] = useState("");
  const [goal, setGoal] = useState<Goal>("both");
  const [sw, setSw] = useState("80");
  const [tw, setTw] = useState("72");
  const [ht, setHt] = useState("170");
  const [sd, setSd] = useState(todayISO());

  const begin = () => {
    completeOnboarding({
      name: name.trim() || "RNDFIT",
      goal,
      startWeightKg: parseFloat(sw) || 80,
      targetWeightKg: parseFloat(tw) || 72,
      heightCm: parseFloat(ht) || 170,
      startDate: sd,
    });
    go("home");
  };

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-5 py-10">
      <Logo size={96} />
      <Wordmark className="mt-3 text-4xl" />
      <p className="mt-2 text-sm font-bold text-flame">{t("sloganAr")}</p>
      <p className="mt-1 text-[10px] tracking-[0.3em] text-mist">{t("sloganEn")}</p>

      <Card className="mt-7 w-full p-5">
        <h1 className="font-display text-2xl font-bold text-snow">{t("obTitle")}</h1>
        <p className="mb-4 mt-0.5 text-xs text-mist">{t("obSub")}</p>

        <Field label={t("language")}>
          <Segmented
            value={lang}
            onChange={(v) => setLang(v)}
            options={[
              { value: "en", label: "English" },
              { value: "ar", label: "العربية" },
            ]}
          />
        </Field>
        <div className="mt-3 space-y-3">
          <Field label={t("obName")}>
            <TextInput value={name} onChange={setName} placeholder={t("obNamePh")} />
          </Field>
          <Field label={t("obGoal")}>
            <Segmented
              value={goal}
              onChange={setGoal}
              options={[
                { value: "lose", label: t("goalLose") },
                { value: "build", label: t("goalBuild") },
                { value: "both", label: t("goalBoth") },
              ]}
            />
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label={t("obStartW")}>
              <NumInput value={sw} onChange={setSw} min={20} max={300} />
            </Field>
            <Field label={t("obTargetW")}>
              <NumInput value={tw} onChange={setTw} min={20} max={300} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Field label={t("obHeight")}>
              <NumInput value={ht} onChange={setHt} min={100} max={230} />
            </Field>
            <Field label={t("obStartD")}>
              <DateInput value={sd} onChange={setSd} />
            </Field>
          </div>
          <Btn className="w-full" onClick={begin}>
            <Icon name="play" size={16} />
            {t("obBegin")}
          </Btn>
        </div>
      </Card>
    </div>
  );
}

function Shell() {
  const { ready, state, t } = useApp();
  const route = useRoute();

  if (!ready) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3">
        <Logo size={80} />
        <Wordmark className="text-3xl" />
      </div>
    );
  }

  if (!state.onboarded) return <Onboarding />;

  const isSub = ["schedule", "live", "reports"].includes(route.name);
  let screen: React.ReactNode = null;
  switch (route.name) {
    case "workouts":
      screen = <Workouts />;
      break;
    case "nutrition":
      screen = <Nutrition />;
      break;
    case "progress":
      screen = <Progress />;
      break;
    case "more":
      screen = <More />;
      break;
    case "schedule":
      screen = <Schedule />;
      break;
    case "live":
      screen = <LiveWorkout key={route.param} planId={route.param === "B" ? "B" : "A"} />;
      break;
    case "reports":
      screen = <Reports />;
      break;
    default:
      screen = <Home />;
  }

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-md px-4 pb-32 pt-4 md:max-w-2xl">
        <Header sub={isSub ? "x" : undefined} />
        {isSub && (
          <p className="mb-2 px-1 font-display text-sm font-semibold uppercase tracking-widest text-flame">
            {route.name === "schedule"
              ? t("weeklySchedule")
              : route.name === "live"
                ? t("liveTitle")
                : t("reportsTitle")}
          </p>
        )}
        <main>{screen}</main>
      </div>
      <BottomNav active={route.name === "schedule" || route.name === "reports" ? "workouts" : route.name === "live" ? "workouts" : route.name} />
    </div>
  );
}

export default function Page() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
