import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const dirScript = `(function(){try{var d=localStorage.getItem('rndfit.data.v1');var l='ar';if(d){var s=JSON.parse(d);l=(s&&s.settings&&s.settings.lang)||'ar';}document.documentElement.lang=l;document.documentElement.dir=l==='ar'?'rtl':'ltr';}catch(e){document.documentElement.lang='ar';document.documentElement.dir='rtl';}})();`;

export const metadata: Metadata = {
  title: "RNDFIT — Stronger Every Day",
  description:
    "RNDFIT bilingual (Arabic / English) fitness app: 12-week plan, dumbbell resistance training, treadmill tracker, nutrition and progress.",
};

export const viewport: Viewport = {
  themeColor: "#0a0a0b",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: dirScript }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,500;0,600;0,700;1,600;1,700&family=Cairo:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-ink text-snow antialiased">{children}</body>
    </html>
  );
}
