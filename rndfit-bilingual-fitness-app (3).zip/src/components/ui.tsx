"use client";

import type { ReactNode } from "react";

/* ---------------- Brand ---------------- */

export function Logo({ size = 44 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" fill="none" aria-label="RNDFIT logo">
      {/* orange speed slash */}
      <path d="M19 106 L45 12 L29 12 L9 80 Z" fill="#FF7A00" />
      <path d="M50 106 L57 78 L49 78 L45 93 Z" fill="#FF7A00" opacity="0.85" />
      {/* bold R */}
      <path d="M82 15 L66 105" stroke="#F5F4F2" strokeWidth="15" />
      <path
        d="M82 15 H100 C116 15 123 23.5 123 38 C123 53.5 111 62 95 62 L117 105"
        stroke="#F5F4F2"
        strokeWidth="15"
        fill="none"
        strokeLinejoin="round"
      />
      {/* runner silhouette inside the bowl counter */}
      <g stroke="#F5F4F2" strokeWidth="3.1" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="104.5" cy="30.5" r="3.6" fill="#F5F4F2" stroke="none" />
        <path d="M103.5 35 L99.5 44" />
        <path d="M103 38 L108.5 40.5" />
        <path d="M103 38 L97.5 41" />
        <path d="M99.5 44 L105.5 49 L104.5 55" />
        <path d="M99.5 44 L93.5 49 L94.5 55" />
      </g>
    </svg>
  );
}

export function Wordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`font-display italic font-bold tracking-[0.04em] ${className}`}>
      RND<span className="text-flame">FIT</span>
    </span>
  );
}

/* ---------------- Icons ---------------- */

const P: Record<string, ReactNode> = {
  home: (
    <>
      <path d="M3.5 11.5 12 4.5l8.5 7" />
      <path d="M5.5 9.8V19a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V9.8" />
    </>
  ),
  dumbbell: (
    <>
      <path d="M7 7.5v9M17 7.5v9M3.5 9.5v5M20.5 9.5v5M7 12h10" />
    </>
  ),
  utensils: (
    <>
      <path d="M7 3.5v17M4.5 3.5V8a2.5 2.5 0 0 0 5 0V3.5" />
      <path d="M17.5 3.5c-1.7 0-2.8 2.2-2.8 5s1.1 5 2.8 5v7M17.5 3.5v10" />
    </>
  ),
  chart: (
    <>
      <path d="M4 19.5h16M6.5 19.5v-6M12 19.5V6M17.5 19.5V10" />
    </>
  ),
  more: <path d="M4 6.5h16M4 12h16M4 17.5h9" />,
  flame: <path d="M12 3c2 3 5 5.6 5 9a5 5 0 0 1-10 0c0-1.5.5-2.9 1.4-4.1C9.4 6.6 11 5 12 3z" />,
  moon: <path d="M20 13.5A8 8 0 1 1 10.5 4 6.5 6.5 0 0 0 20 13.5z" />,
  scale: (
    <>
      <path d="M6 4.5h12l2 15H4l2-15z" />
      <path d="M9 8.5a3 3 0 0 1 6 0" />
    </>
  ),
  calendar: (
    <>
      <path d="M5 6h14v14H5zM5 10.5h14M9 4v4M15 4v4" />
    </>
  ),
  play: <path d="M8.5 5.5v13l10-6.5z" />,
  check: <path d="M4.5 12.5l5 5 10-11" />,
  x: <path d="M6 6l12 12M18 6L6 18" />,
  plus: <path d="M12 5v14M5 12h14" />,
  trash: (
    <>
      <path d="M5 7h14M9.5 7V4.5h5V7M7 7l1 13.5h8L17 7" />
      <path d="M10.2 11v6M13.8 11v6" />
    </>
  ),
  chevL: <path d="M14.5 5.5 8 12l6.5 6.5" />,
  chevD: <path d="M5.5 9.5 12 16l6.5-6.5" />,
  chevR: <path d="M9.5 5.5 16 12l-6.5 6.5" />,
  up: <path d="M12 19V5M5.5 11.5 12 5l6.5 6.5" />,
  down: <path d="M12 5v14M5.5 12.5 12 19l6.5-6.5" />,
  download: <path d="M12 4v10M8 10.5l4 4 4-4M5 19.5h14" />,
  upload: <path d="M12 15V5M8 8.5l4-4 4 4M5 19.5h14" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3.5 2" />
    </>
  ),
  alert: (
    <>
      <path d="M12 4 2.8 19.5h18.4L12 4z" />
      <path d="M12 10v4.5M12 17.6v.01" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <circle cx="12" cy="12" r="4.5" />
      <circle cx="12" cy="12" r="0.8" fill="#F5F4F2" />
    </>
  ),
  skip: <path d="M6 6l8.5 6L6 18zM16.5 6.5v11" />,
  edit: <path d="M4 20l1-4.5L16.5 4 19.5 7 7 19.5 4 20z" />,
  refresh: (
    <>
      <path d="M4.5 12a7.5 7.5 0 0 1 12.9-5.2L19.5 9" />
      <path d="M19.5 4.5V9h-4.5M19.5 12a7.5 7.5 0 0 1-12.9 5.2L4.5 15" />
      <path d="M4.5 19.5V15H9" />
    </>
  ),
  droplet: <path d="M12 4s6 6.3 6 10.2a6 6 0 0 1-12 0C6 10.3 12 4 12 4z" />,
  pulse: <path d="M3 12h4l3-7 4 14 3-7h4" />,
  flag: <path d="M6 21V4M6 4.8c4-2.2 8 2 12 0V13c-4 2.2-8-2-12 0" />,
  runner: (
    <g strokeLinecap="round" strokeLinejoin="round">
      <circle cx="14.5" cy="4.6" r="2.3" fill="currentColor" stroke="none" />
      <path d="M13.8 8 11 15M13.4 10l4.2 1.8M13.4 10 9.5 11.6M11 15l3.6 3-1 4.5M11 15l-3.4 2.8.8 4.2" />
    </g>
  ),
};

export type IconName = keyof typeof P;

export function Icon({
  name,
  size = 20,
  className = "",
  strokeWidth = 1.8,
}: {
  name: IconName;
  size?: number;
  className?: string;
  strokeWidth?: number;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      className={className}
      aria-hidden
    >
      {P[name]}
    </svg>
  );
}

/* ---------------- Layout primitives ---------------- */

export function Card({
  children,
  className = "",
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={`rounded-2xl border border-line bg-surface ${onClick ? "cursor-pointer active:scale-[0.99] transition" : ""} ${className}`}
    >
      {children}
    </div>
  );
}

export function SectionHead({
  title,
  sub,
  icon,
  action,
}: {
  title: string;
  sub?: string;
  icon?: IconName;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3 px-4 pt-4 pb-1">
      <div className="flex items-center gap-2.5 min-w-0">
        {icon && (
          <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-flame/12 text-flame">
            <Icon name={icon} size={17} />
          </span>
        )}
        <div className="min-w-0">
          <h3 className="font-display text-lg font-semibold leading-tight text-snow">{title}</h3>
          {sub && <p className="text-[11px] text-mist leading-tight">{sub}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

export function Ring({
  value,
  size = 110,
  stroke = 9,
  children,
  color = "#FF7A00",
}: {
  value: number;
  size?: number;
  stroke?: number;
  children?: ReactNode;
  color?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.min(1, Math.max(0, value));
  const off = c * (1 - clamped);
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#26262C" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={off}
          style={{ transition: "stroke-dashoffset 0.5s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">{children}</div>
    </div>
  );
}

export function Bar({ value, className = "" }: { value: number; className?: string }) {
  return (
    <div className={`h-2 w-full overflow-hidden rounded-full bg-raised ${className}`}>
      <div
        className="h-full rounded-full bg-flame transition-all"
        style={{ width: `${Math.min(100, Math.max(0, value * 100))}%` }}
      />
    </div>
  );
}

/* ---------------- Buttons & inputs ---------------- */

export function Btn({
  children,
  onClick,
  variant = "primary",
  className = "",
  disabled,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "danger" | "soft";
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none";
  const styles: Record<string, string> = {
    primary: "bg-flame text-ink hover:bg-ember",
    ghost: "border border-line bg-raised text-snow hover:border-mist/40",
    danger: "border border-danger/30 bg-danger/10 text-danger",
    soft: "bg-flame/12 text-flame hover:bg-flame/20",
  };
  return (
    <button type={type} disabled={disabled} onClick={onClick} className={`${base} ${styles[variant]} ${className}`}>
      {children}
    </button>
  );
}

const inputCls =
  "w-full rounded-xl border border-line bg-coal px-3 py-2.5 text-sm text-snow placeholder:text-mist/50 outline-none focus:border-flame/70";

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-mist">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[10px] text-mist/70">{hint}</span>}
    </label>
  );
}

export function NumInput(props: {
  value: string | number;
  onChange: (v: string) => void;
  placeholder?: string;
  min?: number;
  max?: number;
  step?: number;
}) {
  return (
    <input
      type="number"
      inputMode="decimal"
      className={inputCls}
      value={props.value}
      min={props.min}
      max={props.max}
      step={props.step ?? 1}
      placeholder={props.placeholder}
      onChange={(e) => props.onChange(e.target.value)}
    />
  );
}

export function TextInput(props: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <input
      type="text"
      className={inputCls}
      value={props.value}
      placeholder={props.placeholder}
      onChange={(e) => props.onChange(e.target.value)}
    />
  );
}

export function DateInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <input
      type="date"
      className={inputCls}
      value={value}
      onChange={(e) => e.target.value && onChange(e.target.value)}
    />
  );
}

export function SelectInput({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <select className={inputCls} value={value} onChange={(e) => onChange(e.target.value)}>
      {options.map((o) => (
        <option key={o.value} value={o.value} className="bg-coal">
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className = "",
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={`grid gap-1 rounded-xl border border-line bg-coal p-1 ${className}`} style={{ gridTemplateColumns: `repeat(${options.length}, 1fr)` }}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={`rounded-lg px-2 py-2 text-xs font-semibold transition ${
            value === o.value ? "bg-flame text-ink" : "text-mist hover:text-snow"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Scale({
  value,
  onChange,
  low,
  high,
}: {
  value: number;
  onChange: (v: number) => void;
  low: string;
  high: string;
}) {
  return (
    <div>
      <div className="grid grid-cols-5 gap-1.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => onChange(n)}
            className={`rounded-lg py-2.5 text-sm font-bold transition ${
              value >= n ? "bg-flame text-ink" : "bg-raised text-mist"
            }`}
          >
            {n}
          </button>
        ))}
      </div>
      <div className="mt-1 flex justify-between text-[10px] text-mist/80">
        <span>{low}</span>
        <span>{high}</span>
      </div>
    </div>
  );
}

export function Chip({ children, tone = "mist" }: { children: ReactNode; tone?: "mist" | "flame" | "ink" | "danger" }) {
  const tones: Record<string, string> = {
    mist: "bg-raised text-mist",
    flame: "bg-flame/15 text-flame",
    ink: "bg-flame text-ink",
    danger: "bg-danger/15 text-danger",
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function EmptyState({
  icon = "target",
  title,
  sub,
  cta,
  onCta,
}: {
  icon?: IconName;
  title: string;
  sub?: string;
  cta?: string;
  onCta?: () => void;
}) {
  return (
    <div className="flex flex-col items-center gap-2 px-6 py-10 text-center">
      <span className="grid size-12 place-items-center rounded-2xl bg-raised text-mist">
        <Icon name={icon} size={24} />
      </span>
      <p className="text-sm font-semibold text-snow">{title}</p>
      {sub && <p className="text-xs text-mist">{sub}</p>}
      {cta && onCta && (
        <Btn variant="soft" className="mt-2 !py-2 text-xs" onClick={onCta}>
          {cta}
        </Btn>
      )}
    </div>
  );
}

/* ---------------- Modal ---------------- */

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose?: () => void;
  title?: string;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-black/75" onClick={onClose} />
      <div className="relative max-h-[88vh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-line bg-surface p-5 sm:rounded-3xl">
        {title && (
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-display text-xl font-semibold text-snow">{title}</h3>
            {onClose && (
              <button onClick={onClose} className="grid size-8 place-items-center rounded-lg bg-raised text-mist">
                <Icon name="x" size={16} />
              </button>
            )}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

/* ---------------- Charts ---------------- */

export function LineChart({
  points,
  height = 132,
  color = "#FF7A00",
  fmt,
}: {
  points: { label: string; value: number }[];
  height?: number;
  color?: string;
  fmt?: (n: number) => string;
}) {
  if (points.length < 2) return null;
  const W = 340;
  const H = height;
  const padT = 20;
  const padB = 18;
  const padX = 10;
  const vals = points.map((p) => p.value);
  let min = Math.min(...vals);
  let max = Math.max(...vals);
  if (min === max) {
    min -= 1;
    max += 1;
  }
  const span = max - min;
  min -= span * 0.18;
  max += span * 0.18;
  const x = (i: number) => padX + (i * (W - padX * 2)) / (points.length - 1);
  const y = (v: number) => H - padB - ((v - min) / (max - min)) * (H - padT - padB);
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(" ");
  const area = `${path} L${x(points.length - 1).toFixed(1)},${(H - padB).toFixed(1)} L${x(0).toFixed(1)},${(H - padB).toFixed(1)} Z`;
  const f = fmt ?? ((n: number) => String(Math.round(n)));
  const mid = Math.floor(points.length / 2);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ direction: "ltr" }}>
      <path d={area} fill={color} opacity={0.07} />
      <path d={path} fill="none" stroke={color} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
      {points.map((p, i) =>
        points.length <= 16 ? <circle key={i} cx={x(i)} cy={y(p.value)} r={2.5} fill={color} /> : null
      )}
      <text x={x(0)} y={y(points[0].value) - 7} fontSize={9.5} fill="#A3A3AD" textAnchor="start">
        {f(points[0].value)}
      </text>
      <text x={W - padX} y={y(points[points.length - 1].value) - 7} fontSize={9.5} fill="#A3A3AD" textAnchor="end">
        {f(points[points.length - 1].value)}
      </text>
      <text x={x(0)} y={H - 4} fontSize={9} fill="#7c7c86" textAnchor="start">
        {points[0].label}
      </text>
      {points.length > 2 && (
        <text x={x(mid)} y={H - 4} fontSize={9} fill="#7c7c86" textAnchor="middle">
          {points[mid].label}
        </text>
      )}
      <text x={W - padX} y={H - 4} fontSize={9} fill="#7c7c86" textAnchor="end">
        {points[points.length - 1].label}
      </text>
    </svg>
  );
}

export function BarsChart({
  items,
  height = 110,
  fmt,
}: {
  items: { label: string; value: number }[];
  height?: number;
  fmt?: (n: number) => string;
}) {
  if (items.length === 0) return null;
  const max = Math.max(...items.map((i) => i.value), 1);
  const f = fmt ?? ((n: number) => String(n));
  return (
    <div className="flex items-end gap-1.5" style={{ height }}>
      {items.map((it, i) => (
        <div key={i} className="flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-1">
          <span className="text-[9px] tabular-nums text-mist">{it.value > 0 ? f(it.value) : ""}</span>
          <div
            className="w-full max-w-8 rounded-t-md"
            style={{
              height: `${Math.max(3, (it.value / max) * (height - 36))}px`,
              background: it.value > 0 ? "#FF7A00" : "#26262C",
              opacity: it.value > 0 ? 0.92 : 1,
            }}
          />
          <span className="w-full truncate text-center text-[9px] text-mist/80">{it.label}</span>
        </div>
      ))}
    </div>
  );
}

export function DualBars({
  items,
  height = 110,
}: {
  items: { label: string; a: number; b: number }[];
  height?: number;
}) {
  if (items.length === 0) return null;
  const max = Math.max(...items.map((i) => Math.max(i.a, i.b)), 1);
  return (
    <div className="flex items-end gap-2" style={{ height }}>
      {items.map((it, i) => (
        <div key={i} className="flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-1">
          <div className="flex w-full items-end justify-center gap-1" style={{ height: height - 26 }}>
            <div
              className="w-1/3 max-w-4 rounded-t-sm"
              style={{ height: `${(it.a / max) * 100}%`, background: "#3a3a42" }}
              title={`${it.a}`}
            />
            <div
              className="w-1/3 max-w-4 rounded-t-sm"
              style={{ height: `${(it.b / max) * 100}%`, background: "#FF7A00" }}
              title={`${it.b}`}
            />
          </div>
          <span className="w-full truncate text-center text-[9px] text-mist/80">{it.label}</span>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Helpers ---------------- */

export function downloadFile(name: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
