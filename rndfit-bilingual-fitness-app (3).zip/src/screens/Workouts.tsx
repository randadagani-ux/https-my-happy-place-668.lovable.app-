"use client";

import { useState } from "react";
import { useApp } from "@/lib/store";
import { addDaysISO, startOfWeekSat, todayISO, uid } from "@/lib/calc";
import { EXERCISES, MUSCLE_LABELS, phaseForWeek } from "@/lib/data";
import type { MuscleGroup, WorkoutItem } from "@/lib/types";
import {
  Bar,
  Btn,
  Card,
  Chip,
  DateInput,
  Field,
  Icon,
  NumInput,
  SectionHead,
  SelectInput,
  TextInput,
} from "@/components/ui";

function WorkoutEditor({ planId }: { planId: "A" | "B" }) {
  const { state, t, lang, fmtInt, setWorkoutItems } = useApp();
  const items = state.customWorkouts[planId];
  const [libPick, setLibPick] = useState("");
  const [nameEn, setNameEn] = useState("");
  const [nameAr, setNameAr] = useState("");
  const [muscle, setMuscle] = useState<MuscleGroup>("legs");

  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= items.length) return;
    const next = [...items];
    [next[i], next[j]] = [next[j], next[i]];
    setWorkoutItems(planId, next);
  };

  const remove = (i: number) => setWorkoutItems(planId, items.filter((_, x) => x !== i));

  const addLib = () => {
    const def = EXERCISES.find((e) => e.id === libPick);
    if (!def) return;
    setWorkoutItems(planId, [...items, { ...def, id: def.id, libId: def.id }]);
    setLibPick("");
  };

  const addCustom = () => {
    if (!nameEn.trim() && !nameAr.trim()) return;
    const custom: WorkoutItem = {
      id: `c${uid()}`,
      nameEn: nameEn.trim() || nameAr.trim(),
      nameAr: nameAr.trim() || nameEn.trim(),
      muscle,
      unilateral: false,
      cueEn: "",
      cueAr: "",
    };
    setWorkoutItems(planId, [...items, custom]);
    setNameEn("");
    setNameAr("");
  };

  return (
    <div className="space-y-2">
      {items.map((it, i) => (
        <div key={it.id} className="flex items-center gap-2 rounded-xl border border-line bg-coal px-3 py-2">
          <span className="grid size-6 shrink-0 place-items-center rounded-md bg-flame/12 text-[11px] font-bold text-flame">
            {fmtInt(i + 1)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-semibold text-snow">{lang === "ar" ? it.nameAr : it.nameEn}</p>
            <p className="text-[10px] text-mist">{MUSCLE_LABELS[it.muscle][lang]}</p>
          </div>
          <button onClick={() => move(i, -1)} className="grid size-7 place-items-center rounded-md bg-raised text-mist disabled:opacity-30" disabled={i === 0} aria-label={t("moveUp")}>
            <Icon name="up" size={14} />
          </button>
          <button onClick={() => move(i, 1)} className="grid size-7 place-items-center rounded-md bg-raised text-mist disabled:opacity-30" disabled={i === items.length - 1} aria-label={t("moveDown")}>
            <Icon name="down" size={14} />
          </button>
          <button onClick={() => remove(i)} className="grid size-7 place-items-center rounded-md bg-raised text-danger" aria-label={t("removeEx")}>
            <Icon name="trash" size={14} />
          </button>
        </div>
      ))}
      <div className="grid grid-cols-[1fr_auto] items-end gap-2">
        <Field label={t("fromLibrary")}>
          <SelectInput
            value={libPick}
            onChange={setLibPick}
            options={[
              { value: "", label: "—" },
              ...EXERCISES.map((e) => ({ value: e.id, label: lang === "ar" ? e.nameAr : e.nameEn })),
            ]}
          />
        </Field>
        <Btn variant="soft" className="!py-2.5 text-xs" onClick={addLib} disabled={!libPick}>
          <Icon name="plus" size={14} />
        </Btn>
      </div>
      <div className="rounded-xl border border-dashed border-line p-3">
        <p className="mb-2 text-[11px] font-semibold text-mist">{t("custom")}</p>
        <div className="grid grid-cols-2 gap-2">
          <TextInput value={nameEn} onChange={setNameEn} placeholder={t("customEn")} />
          <TextInput value={nameAr} onChange={setNameAr} placeholder={t("customAr")} />
        </div>
        <div className="mt-2 flex items-end gap-2">
          <div className="flex-1">
            <SelectInput
              value={muscle}
              onChange={(v) => setMuscle(v as MuscleGroup)}
              options={(Object.keys(MUSCLE_LABELS) as MuscleGroup[]).map((m) => ({ value: m, label: MUSCLE_LABELS[m][lang] }))}
            />
          </div>
          <Btn variant="ghost" className="!py-2.5 text-xs" onClick={addCustom} disabled={!nameEn.trim() && !nameAr.trim()}>
            <Icon name="plus" size={14} /> {t("add")}
          </Btn>
        </div>
      </div>
    </div>
  );
}

export default function Workouts() {
  const { state, t, lang, fmtNum, fmtInt, fmtDate, week, prescription, addTreadmill, removeTreadmill, updateSettings } = useApp();
  const [editA, setEditA] = useState(false);
  const [editB, setEditB] = useState(false);
  const [walkDate, setWalkDate] = useState(todayISO());
  const [walkMin, setWalkMin] = useState("30");
  const [walkKm, setWalkKm] = useState("");

  const phase = phaseForWeek(week);
  const weekStart = startOfWeekSat(todayISO());
  const weekEnd = addDaysISO(weekStart, 7);
  const walksWeek = state.treadmill.filter((x) => x.date >= weekStart && x.date < weekEnd);
  const walkTotal = walksWeek.reduce((a, x) => a + x.minutes, 0);
  const walkPct = state.settings.walkGoalMin > 0 ? walkTotal / state.settings.walkGoalMin : 0;

  const inProgressA = state.sessions.find((s) => s.status === "in-progress" && s.planId === "A");
  const inProgressB = state.sessions.find((s) => s.status === "in-progress" && s.planId === "B");

  const logWalk = () => {
    const m = parseInt(walkMin, 10);
    if (!m || m <= 0) return;
    addTreadmill({ date: walkDate, minutes: m, km: walkKm ? parseFloat(walkKm) : null });
  };

  return (
    <div className="space-y-3">
      {/* 12-week plan */}
      <Card>
        <SectionHead
          title={t("planTitle")}
          sub={`${t("phase")}: ${lang === "ar" ? phase.phaseAr : phase.phaseEn}`}
          icon="flag"
          action={<Chip tone="flame">{t("weekShort", { w: fmtInt(week) })}</Chip>}
        />
        <div className="px-4 pb-3">
          <p className="text-xs leading-relaxed text-mist">{lang === "ar" ? phase.focusAr : phase.focusEn}</p>
          <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-flame">
            <Icon name="target" size={14} />
            {t("prescriptionSub", { sets: fmtInt(prescription.sets), lo: fmtInt(prescription.lo), hi: fmtInt(prescription.hi), r: fmtInt(prescription.rest) })}
          </p>
          <div className="mt-3 grid grid-cols-6 gap-1.5">
            {Array.from({ length: 12 }, (_, i) => i + 1).map((w) => (
              <span
                key={w}
                className={`grid h-8 place-items-center rounded-lg text-[11px] font-bold ${
                  w === week
                    ? "bg-flame text-ink"
                    : w < week
                      ? "bg-raised text-mist line-through"
                      : "border border-line text-mist"
                }`}
              >
                {fmtInt(w)}
              </span>
            ))}
          </div>
          <p className="mt-3 text-[10px] leading-relaxed text-mist/80">{t("gentleHint")}</p>
        </div>
      </Card>

      {/* Resistance */}
      <Card>
        <SectionHead title={t("resistance")} icon="dumbbell" />
        <div className="space-y-2 px-4 pb-4">
          <div className="grid grid-cols-2 gap-2">
            {(["A", "B"] as const).map((pid) => (
              <div key={pid} className="rounded-xl border border-line bg-coal p-3">
                <p className="font-display text-base font-semibold text-snow">{pid === "A" ? t("typeA") : t("typeB")}</p>
                <p className="mb-2 text-[10px] text-mist">{t("exercisesCount", { n: fmtInt(state.customWorkouts[pid].length) })}</p>
                <Btn
                  className="w-full !py-2 text-xs"
                  onClick={() => (window.location.hash = `#/live/${pid}`)}
                >
                  <Icon name="play" size={13} />
                  {inProgressA && pid === "A" ? t("resume") : inProgressB && pid === "B" ? t("resume") : t("start")}
                </Btn>
                <button
                  onClick={() => (pid === "A" ? setEditA(!editA) : setEditB(!editB))}
                  className="mt-1.5 flex w-full items-center justify-center gap-1 text-[11px] font-semibold text-mist hover:text-flame"
                >
                  <Icon name="edit" size={12} />
                  {t("editWorkouts")}
                </button>
              </div>
            ))}
          </div>
          {editA && (
            <div className="rounded-xl border border-line bg-surface p-3">
              <p className="mb-2 text-xs font-bold text-flame">{t("typeA")}</p>
              <WorkoutEditor planId="A" />
            </div>
          )}
          {editB && (
            <div className="rounded-xl border border-line bg-surface p-3">
              <p className="mb-2 text-xs font-bold text-flame">{t("typeB")}</p>
              <WorkoutEditor planId="B" />
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <Btn variant="ghost" className="!py-2.5 text-xs" onClick={() => (window.location.hash = "#/schedule")}>
              <Icon name="calendar" size={14} className="text-flame" />
              {t("weeklySchedule")}
            </Btn>
            <Btn variant="ghost" className="!py-2.5 text-xs" onClick={() => (window.location.hash = "#/reports")}>
              <Icon name="chart" size={14} className="text-flame" />
              {t("reports")}
            </Btn>
          </div>
        </div>
      </Card>

      {/* Treadmill */}
      <Card>
        <SectionHead title={t("treadmillTitle")} sub={t("thisWeekTotal")} icon="pulse" />
        <div className="px-4 pb-4">
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="text-mist">
              {fmtInt(walkTotal)} / {fmtInt(state.settings.walkGoalMin)} {t("minutes")}
            </span>
            <span className="font-semibold text-flame">{fmtInt(walkPct * 100)}%</span>
          </div>
          <Bar value={walkPct} />
          <div className="mt-2 flex items-center gap-2">
            <span className="text-[10px] text-mist">{t("walkGoalSet")}</span>
            <input
              type="number"
              className="w-20 rounded-lg border border-line bg-coal px-2 py-1 text-xs text-snow outline-none focus:border-flame/70"
              value={state.settings.walkGoalMin}
              onChange={(e) => updateSettings({ walkGoalMin: Math.max(0, parseInt(e.target.value, 10) || 0) })}
            />
          </div>

          <div className="mt-3 grid grid-cols-3 gap-2">
            <Field label={t("date")}>
              <DateInput value={walkDate} onChange={setWalkDate} />
            </Field>
            <Field label={`${t("minutes")}`}>
              <NumInput value={walkMin} onChange={setWalkMin} min={1} />
            </Field>
            <Field label={t("km")}>
              <NumInput value={walkKm} onChange={setWalkKm} placeholder="—" />
            </Field>
          </div>
          <Btn className="mt-2 w-full !py-2.5 text-xs" onClick={logWalk}>
            <Icon name="plus" size={14} />
            {t("logWalk")}
          </Btn>

          <div className="mt-3 space-y-1.5">
            {walksWeek
              .slice()
              .sort((a, b) => b.date.localeCompare(a.date))
              .map((w) => (
                <div key={w.id} className="flex items-center justify-between rounded-lg bg-coal px-3 py-2 text-xs">
                  <span className="text-mist">{fmtDate(w.date)}</span>
                  <span className="font-semibold text-snow">
                    {fmtNum(w.minutes)} {t("minutes")}
                    {w.km != null && (
                      <span className="ms-2 text-mist">
                        {fmtNum(w.km)} {lang === "ar" ? "كم" : "km"}
                      </span>
                    )}
                  </span>
                  <button onClick={() => removeTreadmill(w.id)} className="text-mist hover:text-danger" aria-label={t("delete")}>
                    <Icon name="trash" size={14} />
                  </button>
                </div>
              ))}
            {walksWeek.length === 0 && <p className="py-2 text-center text-[11px] text-mist">{t("noWalks")}</p>}
          </div>
        </div>
      </Card>
    </div>
  );
}
