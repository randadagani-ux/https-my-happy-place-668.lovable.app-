"use client";

import { useState } from "react";
import { useApp } from "@/lib/store";
import {
  addDaysISO,
  allUniqueItems,
  completedSessionsIn,
  exerciseSeries,
  itemsById,
  muscleGroupSets,
  overloadSuggestions,
  plannedStrengthDays,
  prevDeltas,
  sessionStats,
  setRepsTotal,
  startOfWeekSat,
  todayISO,
  volumeBetween,
} from "@/lib/calc";
import { MUSCLE_LABELS } from "@/lib/data";
import type { SetRecord, WorkoutSession } from "@/lib/types";
import { BarsChart, Btn, Card, Chip, DualBars, EmptyState, Icon, LineChart, SectionHead, Segmented } from "@/components/ui";

export default function Reports() {
  const { state, t, lang, fmtNum, fmtInt, fmtDate, prescription, approveProgression } = useApp();
  const [rangeWeeks, setRangeWeeks] = useState<4 | 8 | 12>(8);
  const [exFilter, setExFilter] = useState<string>("all");

  const today = todayISO();
  const curWeekStart = startOfWeekSat(today);
  const from = addDaysISO(curWeekStart, -7 * (rangeWeeks - 1));
  const to = addDaysISO(curWeekStart, 6);

  const items = itemsById(state);
  const all = allUniqueItems(state);
  const completed = completedSessionsIn(state.sessions, from, to);

  const buckets = Array.from({ length: rangeWeeks }, (_, i) => {
    const start = addDaysISO(curWeekStart, -7 * (rangeWeeks - 1 - i));
    return {
      start,
      end: addDaysISO(start, 6),
      label: fmtDate(start),
    };
  });

  // which exercise to chart when "all"
  let chartId = exFilter;
  if (chartId === "all") {
    let bestId = "";
    let bestVol = -1;
    for (const it of all) {
      const pts = exerciseSeries(state.sessions, items, it.id).filter((p) => p.date >= from && p.date <= to);
      const vol = pts.reduce((a, p) => a + p.volume, 0);
      if (vol > bestVol) {
        bestVol = vol;
        bestId = it.id;
      }
    }
    chartId = bestId;
  }
  const chartItem = chartId !== "all" ? items.get(chartId) : undefined;
  const series = chartItem ? exerciseSeries(state.sessions, items, chartItem.id).filter((p) => p.date >= from && p.date <= to) : [];

  // best per exercise in range
  const bests = all
    .map((it) => {
      let best: { w: number; r: number; date: string } | null = null;
      for (const s of completed) {
        for (const set of s.sets) {
          if (set.exerciseInstanceId !== it.id || !set.completed) continue;
          const r = setRepsTotal(set);
          if (!best || set.weightKg * r > best.w * best.r) best = { w: set.weightKg, r, date: s.date };
        }
      }
      const d = prevDeltas(state.sessions, it.id);
      return { it, best, d };
    })
    .filter((b) => b.best !== null);

  const sugg = overloadSuggestions(state);
  const thisWeek = volumeBetween(state.sessions, items, curWeekStart, today);
  const compWeek = {
    done: completedSessionsIn(state.sessions, curWeekStart, today).length,
    planned: plannedStrengthDays(state.schedule, Math.min(12, Math.max(1, Math.floor((new Date(today).getTime() - new Date(state.profile.startDate).getTime()) / (7 * 86400000)) + 1))).length,
  };
  const muscles = muscleGroupSets(state.sessions, items, curWeekStart, today);

  const topGains = bests
    .filter((b) => b.d && (b.d.dw > 0 || b.d.dr > 0) && b.best && b.best.date >= curWeekStart)
    .sort((a, b) => (b.d!.dw - a.d!.dw) || (b.d!.dr - a.d!.dr))
    .slice(0, 3);

  if (completed.length === 0 && bests.length === 0) {
    return (
      <div className="space-y-3">
        <h1 className="px-1 pt-2 font-display text-2xl font-bold text-snow">{t("reportsTitle")}</h1>
        <Card>
          <EmptyState
            icon="chart"
            title={t("noData")}
            sub={t("noReports")}
            cta={t("noReportsCta")}
            onCta={() => (window.location.hash = "#/workouts")}
          />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="px-1 pt-2">
        <h1 className="font-display text-2xl font-bold text-snow">{t("reportsTitle")}</h1>
      </div>

      {/* Filters */}
      <Card className="space-y-2 p-3.5">
        <Segmented
          value={String(rangeWeeks)}
          onChange={(v) => setRangeWeeks(parseInt(v, 10) as 4 | 8 | 12)}
          options={[
            { value: "4", label: t("last4w") },
            { value: "8", label: t("last8w") },
            { value: "12", label: t("last12w") },
          ]}
        />
        <select
          className="w-full rounded-xl border border-line bg-coal px-3 py-2.5 text-sm text-snow outline-none focus:border-flame/70"
          value={exFilter}
          onChange={(e) => setExFilter(e.target.value)}
        >
          <option value="all">{t("allEx")}</option>
          {all.map((it) => (
            <option key={it.id} value={it.id}>
              {lang === "ar" ? it.nameAr : it.nameEn}
            </option>
          ))}
        </select>
      </Card>

      {/* Weekly review */}
      <Card className="border-flame/30 p-4">
        <p className="flex items-center gap-2 font-display text-lg font-bold text-flame">
          <Icon name="flag" size={17} />
          {t("weeklyReview")}
        </p>
        <div className="mt-3 grid grid-cols-4 gap-2 text-center">
          <div className="rounded-xl bg-coal p-2.5">
            <p className="text-[9px] text-mist">{t("sessions")}</p>
            <p className="font-display text-lg font-bold text-snow">
              {fmtInt(compWeek.done)}/{fmtInt(compWeek.planned)}
            </p>
          </div>
          <div className="rounded-xl bg-coal p-2.5">
            <p className="text-[9px] text-mist">{t("volume")}</p>
            <p className="font-display text-lg font-bold text-flame">{fmtInt(thisWeek.volume)}</p>
          </div>
          <div className="rounded-xl bg-coal p-2.5">
            <p className="text-[9px] text-mist">{t("totalSets")}</p>
            <p className="font-display text-lg font-bold text-snow">{fmtInt(thisWeek.sets)}</p>
          </div>
          <div className="rounded-xl bg-coal p-2.5">
            <p className="text-[9px] text-mist">{t("totalReps")}</p>
            <p className="font-display text-lg font-bold text-snow">{fmtInt(thisWeek.reps)}</p>
          </div>
        </div>
        <p className="mb-1.5 mt-3 text-[10px] font-bold uppercase tracking-wide text-mist">{t("topGains")}</p>
        {topGains.length > 0 ? (
          <div className="space-y-1.5">
            {topGains.map((b) => (
              <div key={b.it.id} className="flex items-center justify-between rounded-lg bg-coal px-3 py-2 text-xs">
                <span className="min-w-0 flex-1 truncate text-snow">{lang === "ar" ? b.it.nameAr : b.it.nameEn}</span>
                <span className="ms-2 font-semibold text-flame">
                  {b.d!.dw > 0 && `+${fmtNum(b.d!.dw)} ${t("kg")} `}
                  {b.d!.dr > 0 && `+${fmtInt(b.d!.dr)} ${t("reps")}`}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-[11px] text-mist">{t("topGainsNone")}</p>
        )}
        <p className="mt-3 border-t border-line pt-2 text-[10px] leading-relaxed text-mist/80">{t("progressNote")}</p>
      </Card>

      {/* Weight / reps over time */}
      {chartItem && (
        <Card>
          <SectionHead
            title={lang === "ar" ? chartItem.nameAr : chartItem.nameEn}
            sub={chartId === exFilter ? "" : exFilter === "all" ? undefined : undefined}
            icon="dumbbell"
          />
          <div className="px-3 pb-2">
            <p className="px-1 pb-1 text-[10px] font-bold uppercase tracking-wide text-mist">
              {t("weightOver")} ({t("kg")})
            </p>
            {series.length >= 2 ? (
              <LineChart points={series.map((p) => ({ label: fmtDate(p.date), value: p.weight }))} fmt={(n) => fmtNum(n)} />
            ) : (
              <p className="py-4 text-center text-[11px] text-mist">{t("noData")}</p>
            )}
            <p className="px-1 pb-1 pt-3 text-[10px] font-bold uppercase tracking-wide text-mist">
              {t("repsOver")}
            </p>
            {series.length >= 2 ? (
              <LineChart points={series.map((p) => ({ label: fmtDate(p.date), value: p.topReps }))} fmt={(n) => fmtInt(n)} color="#FFA24D" />
            ) : (
              <p className="py-4 text-center text-[11px] text-mist">{t("noData")}</p>
            )}
          </div>
        </Card>
      )}

      {/* Weekly volume */}
      <Card>
        <SectionHead title={t("weeklyVolume")} sub={`${t("kg")}`} icon="chart" />
        <div className="px-3 pb-3">
          <BarsChart
            items={buckets.map((b) => ({ label: b.label, value: Math.round(volumeBetween(state.sessions, items, b.start, b.end).volume) }))}
            fmt={(n) => fmtInt(n)}
          />
        </div>
      </Card>

      {/* Planned vs completed */}
      <Card>
        <SectionHead title={t("plannedVs")} icon="calendar" />
        <div className="px-3 pb-2">
          <DualBars
            items={buckets.map((b) => ({
              label: b.label,
              a: plannedStrengthDays(state.schedule, weekOf(state, b.start)).length,
              b: completedSessionsIn(state.sessions, b.start, b.end).length,
            }))}
          />
          <div className="mt-2 flex gap-4 px-1 text-[10px] text-mist">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-sm bg-[#3a3a42]" />
              {t("planned")}
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-sm bg-flame" />
              {t("completedL")}
            </span>
          </div>
        </div>
      </Card>

      {/* Consistency */}
      <Card>
        <SectionHead title={t("consistency")} icon="pulse" />
        <div className="px-3 pb-3">
          <BarsChart
            items={buckets.map((b) => {
              const planned = plannedStrengthDays(state.schedule, weekOf(state, b.start)).length;
              const done = completedSessionsIn(state.sessions, b.start, b.end).length;
              return { label: b.label, value: planned > 0 ? Math.round((done / planned) * 100) : 0 };
            })}
            fmt={(n) => `${fmtInt(n)}%`}
          />
        </div>
      </Card>

      {/* Best performance */}
      <Card>
        <SectionHead title={t("bests")} sub={t("vsPrev")} icon="target" />
        <div className="space-y-1.5 px-4 pb-4">
          {bests.map(({ it, best, d }) => (
            <div key={it.id} className="rounded-xl bg-coal px-3 py-2.5">
              <div className="flex items-center justify-between gap-2">
                <p className="min-w-0 flex-1 truncate text-xs font-semibold text-snow">{lang === "ar" ? it.nameAr : it.nameEn}</p>
                {state.approvedProgression[it.id] && <Chip tone="ink">{t("approvedChip")}</Chip>}
              </div>
              <div className="mt-1 flex items-center justify-between text-[11px]">
                <span className="tabular-nums text-flame">
                  {fmtNum(best!.w)} {t("kg")} × {fmtInt(best!.r)}
                  <span className="ms-1.5 text-mist">
                    {t("on")} {fmtDate(best!.date)}
                  </span>
                </span>
                <span className="tabular-nums text-mist">
                  {d && (
                    <>
                      {d.dw !== 0 && (
                        <span className={d.dw > 0 ? "text-flame" : "text-mist"}>
                          {d.dw > 0 ? "+" : ""}
                          {fmtNum(d.dw)} {t("kg")}
                        </span>
                      )}
                      {d.dr !== 0 && (
                        <span className={d.dr > 0 ? "text-flame" : "text-mist"}>
                          {" "}
                          {d.dr > 0 ? "+" : ""}
                          {fmtInt(d.dr)} {t("reps")}
                        </span>
                      )}
                    </>
                  )}
                </span>
              </div>
            </div>
          ))}
          {bests.length === 0 && <p className="py-3 text-center text-[11px] text-mist">{t("noBest")}</p>}
        </div>
      </Card>

      {/* Suggestions */}
      <Card>
        <SectionHead title={t("suggestions")} icon="flame" />
        <div className="space-y-2 px-4 pb-4">
          {sugg.length > 0 ? (
            sugg.map((s) => {
              const it = items.get(s.itemId);
              if (!it) return null;
              const approved = !!state.approvedProgression[s.itemId];
              return (
                <div key={s.itemId} className="rounded-xl border border-flame/25 bg-coal p-3">
                  <p className="text-xs font-semibold text-snow">{lang === "ar" ? it.nameAr : it.nameEn}</p>
                  <p className="mt-0.5 text-[11px] text-flame">
                    {s.kind === "weight" && t("sugWeight", { w: fmtNum(s.weightKg ?? 0) })}
                    {s.kind === "reps" && t("sugReps")}
                    {s.kind === "hold" && t("sugHold")}
                  </p>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-[9px] text-mist/70">{t("sugRule")}</span>
                    {approved ? (
                      <Chip tone="ink">
                        <Icon name="check" size={11} />
                        {t("approvedChip")}
                      </Chip>
                    ) : (
                      <Btn
                        variant="soft"
                        className="!px-3 !py-1.5 text-[11px]"
                        onClick={() =>
                          approveProgression(s.itemId, s.kind === "weight" ? { weightKg: s.weightKg } : s.kind === "reps" ? { targetReps: (prescription.hi ?? 10) + 1 } : {})
                        }
                      >
                        {t("approve")}
                      </Btn>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <p className="py-2 text-center text-[11px] text-mist">{t("noSuggestions")}</p>
          )}
        </div>
      </Card>

      {/* Muscle groups */}
      {muscles.length > 0 && (
        <Card>
          <SectionHead title={t("muscSets")} sub={t("thisWeek")} icon="dumbbell" />
          <div className="flex flex-wrap gap-1.5 px-4 pb-4">
            {muscles.map((m) => (
              <Chip key={m.group} tone="flame">
                {MUSCLE_LABELS[m.group][lang]} • {fmtInt(m.count)}
              </Chip>
            ))}
          </div>
        </Card>
      )}

      {/* Session history */}
      <Card>
        <SectionHead title={t("history")} sub={t("historySub")} icon="clock" />
        <div className="space-y-2 px-4 pb-4">
          {[...state.sessions]
            .filter((s) => s.sets.length > 0 || s.status === "skipped")
            .sort((a, b) => b.date.localeCompare(a.date))
            .slice(0, 12)
            .map((s) => (
              <HistorySession key={s.id} session={s} />
            ))}
          {state.sessions.length === 0 && (
            <p className="py-2 text-center text-[11px] text-mist">{t("noData")}</p>
          )}
        </div>
      </Card>

      <p className="px-1 pb-2 text-[10px] leading-relaxed text-mist/70">
        {t("volumeNote", { conv: state.settings.weightConvention === "per" ? t("perDumbbell") : t("combined") })}
      </p>
    </div>
  );
}

function HistorySession({ session }: { session: WorkoutSession }) {
  const { state, t, fmtInt, fmtDate } = useApp();
  const [open, setOpen] = useState(false);
  const items = itemsById(state);
  const stats = sessionStats(session, items);
  return (
    <div className="rounded-xl border border-line bg-coal">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between gap-2 px-3 py-2.5 text-xs"
      >
        <span className="font-semibold text-snow">
          {fmtDate(session.date, "medium")} • {session.planId}
        </span>
        <span className="flex items-center gap-2">
          {session.status === "skipped" ? (
            <Chip tone="danger">{t("skippedSession")}</Chip>
          ) : (
            <span className="tabular-nums text-mist">
              {fmtInt(stats.setsDone)} {t("setsUnit")} • {fmtInt(stats.volume)} {t("kg")}
            </span>
          )}
          <Icon name="chevD" size={14} className={`transition ${open ? "rotate-180 text-flame" : "text-mist"}`} />
        </span>
      </button>
      {open && session.sets.length > 0 && (
        <div className="space-y-1.5 border-t border-line p-2.5">
          {session.sets.map((set) => (
            <SetRow key={set.id} session={session} set={set} />
          ))}
        </div>
      )}
    </div>
  );
}

function SetRow({ session, set }: { session: WorkoutSession; set: SetRecord }) {
  const { state, t, lang, fmtInt, updateSet, removeSet } = useApp();
  const items = itemsById(state);
  const item = items.get(set.exerciseInstanceId);
  const [w, setW] = useState(set.weightKg ? String(set.weightKg) : "");
  const [r, setR] = useState(set.reps ? String(set.reps) : "");
  const [l, setL] = useState(set.repsLeft != null ? String(set.repsLeft) : "");
  const [rr, setRR] = useState(set.repsRight != null ? String(set.repsRight) : "");

  const save = () => {
    if (item?.unilateral) {
      const L = parseInt(l, 10) || 0;
      const R = parseInt(rr, 10) || 0;
      updateSet(session.id, set.id, { weightKg: parseFloat(w) || 0, repsLeft: L, repsRight: R, reps: L + R });
    } else {
      updateSet(session.id, set.id, { weightKg: parseFloat(w) || 0, reps: parseInt(r, 10) || 0 });
    }
  };

  const cls =
    "w-14 rounded-md border border-line bg-surface px-1.5 py-1 text-[11px] tabular-nums text-snow outline-none focus:border-flame/70";

  return (
    <div className="flex flex-wrap items-center gap-1.5 rounded-lg bg-surface px-2.5 py-2">
      <span className="w-6 text-center text-[10px] font-bold text-flame" title={t("setNum", { n: fmtInt(set.setNumber) })}>
        {fmtInt(set.setNumber)}
      </span>
      <span className="min-w-0 flex-1 truncate text-[10px] font-semibold text-snow">
        {lang === "ar" ? item?.nameAr : item?.nameEn}
      </span>
      <span className="text-[9px] text-mist">RPE {fmtInt(set.rpe)}</span>
      <input type="number" step={0.5} min={0} value={w} onChange={(e) => setW(e.target.value)} className={cls} aria-label={`${t("kg")}`} />
      {item?.unilateral ? (
        <>
          <input type="number" min={0} value={l} onChange={(e) => setL(e.target.value)} className={`${cls} w-12`} aria-label={t("leftArm")} />
          <input type="number" min={0} value={rr} onChange={(e) => setRR(e.target.value)} className={`${cls} w-12`} aria-label={t("rightArm")} />
        </>
      ) : (
        <input type="number" min={0} value={r} onChange={(e) => setR(e.target.value)} className={cls} aria-label={t("reps")} />
      )}
      <button onClick={save} className="grid size-6 place-items-center rounded-md bg-flame/15 text-flame active:scale-95" aria-label={t("save")}>
        <Icon name="check" size={12} />
      </button>
      <button onClick={() => removeSet(session.id, set.id)} className="grid size-6 place-items-center rounded-md bg-danger/12 text-danger active:scale-95" aria-label={t("delete")}>
        <Icon name="trash" size={12} />
      </button>
    </div>
  );
}

function weekOf(state: { profile: { startDate: string } }, iso: string): number {
  const diff = Math.floor((new Date(`${iso}T12:00:00`).getTime() - new Date(`${state.profile.startDate}T12:00:00`).getTime()) / (7 * 86400000));
  return Math.min(12, Math.max(1, diff + 1));
}
