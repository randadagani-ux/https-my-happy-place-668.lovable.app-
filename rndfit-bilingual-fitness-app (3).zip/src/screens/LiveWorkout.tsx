"use client";

import { useEffect, useState } from "react";
import { useApp } from "@/lib/store";
import {
  durationFmt,
  lastCompletedSetFor,
  sessionStats,
  setRepsTotal,
  setVolume,
  todayISO,
} from "@/lib/calc";
import { MUSCLE_LABELS } from "@/lib/data";
import type { Readiness } from "@/lib/types";
import { Btn, Card, Chip, Field, Icon, Modal, NumInput, Ring, SelectInput, TextInput } from "@/components/ui";

export default function LiveWorkout({ planId }: { planId: "A" | "B" }) {
  const app = useApp();
  const { state, t, lang, fmtNum, fmtInt, fmtDate, prescription } = app;

  const [phase, setPhase] = useState<"setup" | "active" | "done">("setup");
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [ready, setReady] = useState<Readiness>({ sleep: 3, energy: 3, soreness: 2 });
  const [exIdx, setExIdx] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [restEnds, setRestEnds] = useState<number | null>(null);

  // set inputs
  const [weight, setWeight] = useState("");
  const [reps, setReps] = useState("");
  const [repsL, setRepsL] = useState("");
  const [repsR, setRepsR] = useState("");
  const [rpe, setRpe] = useState("7");
  const [notes, setNotes] = useState("");
  const [finishOpen, setFinishOpen] = useState(false);

  const items = state.customWorkouts[planId];
  const session = sessionId ? state.sessions.find((s) => s.id === sessionId) ?? null : null;

  // resume or new
  useEffect(() => {
    const existing = state.sessions.find(
      (s) => s.status === "in-progress" && s.planId === planId && s.date === todayISO()
    );
    if (existing) {
      setSessionId(existing.id);
      setPhase("active");
      const P = existing.reduced ? Math.max(1, prescription.sets - 1) : prescription.sets;
      const list = state.customWorkouts[planId];
      const firstOpen = list.findIndex(
        (it) => existing.sets.filter((s) => s.exerciseInstanceId === it.id).length < P
      );
      setExIdx(firstOpen >= 0 ? firstOpen : Math.max(0, list.length - 1));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [planId]);

  // tick
  useEffect(() => {
    if (phase !== "active") return;
    const iv = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(iv);
  }, [phase]);

  // prefill per exercise
  useEffect(() => {
    const item = items[exIdx];
    if (!item) return;
    const approved = state.approvedProgression[item.id];
    const todaySet = session?.sets.find((s) => s.exerciseInstanceId === item.id && s.completed);
    const last = lastCompletedSetFor(state.sessions, item.id, todayISO());
    const w = approved?.weightKg ?? todaySet?.weightKg ?? last?.weightKg ?? null;
    setWeight(w != null ? String(w) : "");
    const tr = approved?.targetReps ?? prescription.hi;
    setReps(String(Math.max(1, tr)));
    setRepsL("");
    setRepsR("");
    setRpe("7");
    setNotes("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [exIdx, sessionId]);

  const P = session && session.reduced ? Math.max(1, prescription.sets - 1) : prescription.sets;
  const item = items[Math.min(exIdx, items.length - 1)];
  const doneSetsFor = (id: string) =>
    session?.sets.filter((s) => s.exerciseInstanceId === id).length ?? 0;
  const curSets = item ? doneSetsFor(item.id) : 0;
  const curSetNo = Math.min(curSets + 1, P);
  const allDone = items.length > 0 && items.every((it) => doneSetsFor(it.id) >= P);

  const restLeft = restEnds != null ? Math.max(0, Math.ceil((restEnds - now) / 1000)) : 0;
  const resting = restEnds != null && restLeft > 0;
  const restPct = restEnds != null && prescription.rest > 0 ? restLeft / prescription.rest : 0;

  const elapsed = session?.startedAt ? now - new Date(session.startedAt).getTime() : 0;

  const poorReady = (ready.sleep + ready.energy + (6 - ready.soreness)) / 3 < 2.8;

  const begin = (useReduced: boolean) => {
    const id = app.startSession(planId, ready, useReduced);
    setSessionId(id);
    setExIdx(0);
    setPhase("active");
  };

  const completeSet = (completed: boolean) => {
    if (!session || !item) return;
    const w = parseFloat(weight) || 0;
    let l: number | null = null;
    let r: number | null = null;
    let total: number;
    if (item.unilateral) {
      l = parseInt(repsL, 10) || 0;
      r = parseInt(repsR, 10) || 0;
      total = l + r;
    } else {
      total = parseInt(reps, 10) || 0;
    }
    app.addSet(session.id, {
      exerciseInstanceId: item.id,
      setNumber: curSetNo,
      weightKg: completed ? w : 0,
      reps: total,
      repsLeft: l,
      repsRight: r,
      targetReps: prescription.hi,
      restSeconds: prescription.rest,
      rpe: parseInt(rpe, 10) || 7,
      notes,
      completed,
    });
    if (completed) {
      setRestEnds(Date.now() + prescription.rest * 1000);
    }
    if (curSetNo >= P && exIdx + 1 < items.length) {
      if (!completed) setRestEnds(null);
      setExIdx(exIdx + 1);
    }
  };

  const finish = () => {
    if (!session) return;
    app.finishSession(session.id);
    setFinishOpen(false);
    setPhase("done");
  };

  const stats = session ? sessionStats(session, new Map([...state.customWorkouts.A, ...state.customWorkouts.B].map((x) => [x.id, x]))) : null;

  /* ---------------- SETUP: readiness ---------------- */
  if (phase === "setup") {
    return (
      <div className="space-y-3">
        <div className="px-1 pt-2">
          <h1 className="font-display text-2xl font-bold text-snow">
            {planId === "A" ? t("workoutA") : t("workoutB")}
          </h1>
          <p className="mt-0.5 text-xs text-mist">
            {t("exercisesCount", { n: fmtInt(items.length) })} • {t("prescriptionSub", { sets: fmtInt(prescription.sets), lo: fmtInt(prescription.lo), hi: fmtInt(prescription.hi), r: fmtInt(prescription.rest) })}
          </p>
        </div>
        <Card className="p-4">
          <p className="flex items-center gap-2 text-sm font-bold text-snow">
            <Icon name="check" size={16} className="text-flame" />
            {t("readiness")}
          </p>
          <p className="mb-4 mt-0.5 text-[11px] text-mist">{t("readinessSub")}</p>
          <div className="space-y-4">
            <div>
              <p className="mb-1.5 text-xs font-medium text-mist">{t("sleepQuality")}</p>
              <div className="grid grid-cols-5 gap-1.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} onClick={() => setReady((s) => ({ ...s, sleep: n }))} className={`rounded-lg py-2.5 text-sm font-bold ${ready.sleep >= n ? "bg-flame text-ink" : "bg-raised text-mist"}`}>
                    {fmtInt(n)}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium text-mist">{t("energy")}</p>
              <div className="grid grid-cols-5 gap-1.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} onClick={() => setReady((s) => ({ ...s, energy: n }))} className={`rounded-lg py-2.5 text-sm font-bold ${ready.energy >= n ? "bg-flame text-ink" : "bg-raised text-mist"}`}>
                    {fmtInt(n)}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium text-mist">{t("soreness")}</p>
              <div className="grid grid-cols-5 gap-1.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} onClick={() => setReady((s) => ({ ...s, soreness: n }))} className={`rounded-lg py-2.5 text-sm font-bold ${ready.soreness >= n ? "bg-flame text-ink" : "bg-raised text-mist"}`}>
                    {fmtInt(n)}
                  </button>
                ))}
              </div>
            </div>
          </div>
          {poorReady ? (
            <div className="mt-4 rounded-xl border border-flame/40 bg-flame/8 p-3">
              <p className="flex items-start gap-2 text-xs leading-relaxed text-snow">
                <Icon name="alert" size={15} className="mt-0.5 shrink-0 text-flame" />
                {t("poorReady")}
              </p>
              <div className="mt-3 grid grid-cols-1 gap-2">
                <Btn className="w-full !py-2.5 text-xs" onClick={() => begin(true)}>
                  {t("reduceSets", { n: fmtInt(Math.max(1, prescription.sets - 1)) })}
                </Btn>
                <Btn variant="ghost" className="w-full !py-2.5 text-xs" onClick={() => begin(false)}>
                  {t("continueNormal")}
                </Btn>
              </div>
            </div>
          ) : (
            <Btn className="mt-4 w-full" onClick={() => begin(false)}>
              <Icon name="play" size={16} />
              {t("startNow")}
            </Btn>
          )}
        </Card>
        <SafetyCard t={t} />
      </div>
    );
  }

  /* ---------------- DONE: final summary ---------------- */
  if (phase === "done" && session) {
    const items2 = new Map([...state.customWorkouts.A, ...state.customWorkouts.B].map((x) => [x.id, x]));
    return (
      <div className="space-y-3">
        <Card className="p-5 text-center">
          <span className="mx-auto grid size-14 place-items-center rounded-full bg-flame text-ink">
            <Icon name="check" size={28} strokeWidth={2.4} />
          </span>
          <h1 className="mt-3 font-display text-2xl font-bold text-snow">{t("finishedTitle")}</h1>
          <p className="mt-1 text-xs text-mist">{t("finishedSub")}</p>
        </Card>
        <Card className="p-4">
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="rounded-xl bg-coal p-2.5">
              <p className="text-[9px] text-mist">{t("duration")}</p>
              <p className="font-display text-lg font-bold text-flame">{durationFmt(new Date(session.finishedAt ?? "").getTime() - new Date(session.startedAt ?? "").getTime())}</p>
            </div>
            <div className="rounded-xl bg-coal p-2.5">
              <p className="text-[9px] text-mist">{t("totalSets")}</p>
              <p className="font-display text-lg font-bold text-snow">{fmtInt(stats?.setsDone ?? 0)}</p>
            </div>
            <div className="rounded-xl bg-coal p-2.5">
              <p className="text-[9px] text-mist">{t("totalReps")}</p>
              <p className="font-display text-lg font-bold text-snow">{fmtInt(stats?.reps ?? 0)}</p>
            </div>
            <div className="rounded-xl bg-coal p-2.5">
              <p className="text-[9px] text-mist">{t("volume")}</p>
              <p className="font-display text-lg font-bold text-snow">{fmtInt(stats?.volume ?? 0)}</p>
            </div>
          </div>
          <div className="mt-3 space-y-1.5">
            {items.map((it) => {
              const sets = session.sets.filter((s) => s.exerciseInstanceId === it.id);
              const done = sets.filter((s) => s.completed);
              const vol = done.reduce((a, s) => a + setVolume(s, it), 0);
              return (
                <div key={it.id} className="flex items-center justify-between rounded-lg bg-coal px-3 py-2 text-xs">
                  <span className="min-w-0 flex-1 truncate text-snow">{lang === "ar" ? it.nameAr : it.nameEn}</span>
                  <span className="ms-2 tabular-nums text-mist">
                    {fmtInt(done.length)}/{fmtInt(P)} • {fmtInt(vol)} {t("kg")}
                  </span>
                  {done.length >= P ? <Chip tone="ink"><Icon name="check" size={11} /></Chip> : <Chip tone="mist">—</Chip>}
                </div>
              );
            })}
          </div>
        </Card>
        <div className="grid grid-cols-2 gap-2">
          <Btn onClick={() => (window.location.hash = "#/home")}>{t("toDashboard")}</Btn>
          <Btn variant="ghost" onClick={() => (window.location.hash = "#/reports")}>
            <Icon name="chart" size={15} className="text-flame" />
            {t("viewReports")}
          </Btn>
        </div>
      </div>
    );
  }

  /* ---------------- ACTIVE ---------------- */
  if (!session || !item) return null;
  const items2 = new Map([...state.customWorkouts.A, ...state.customWorkouts.B].map((x) => [x.id, x]));

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1 pt-2">
        <div>
          <h1 className="font-display text-2xl font-bold text-snow">{t("liveTitle")}</h1>
          <p className="mt-0.5 text-xs text-mist">
            {planId === "A" ? t("workoutA") : t("workoutB")}
          </p>
        </div>
        <div className="text-end">
          <p className="font-display text-xl font-bold tabular-nums text-flame">{durationFmt(elapsed)}</p>
          <p className="text-[9px] text-mist">{t("elapsed")}</p>
        </div>
      </div>

      {/* exercise strip */}
      <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
        {items.map((it, i) => {
          const dn = doneSetsFor(it.id);
          const full = dn >= P;
          return (
            <button
              key={it.id}
              onClick={() => setExIdx(i)}
              className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold transition ${
                i === exIdx
                  ? "border-flame bg-flame/15 text-flame"
                  : full
                    ? "border-line bg-raised text-mist"
                    : "border-line bg-coal text-snow"
              }`}
            >
              {full && <Icon name="check" size={11} />}
              <span className="max-w-28 truncate">{fmtInt(i + 1)}. {lang === "ar" ? it.nameAr : it.nameEn}</span>
            </button>
          );
        })}
      </div>

      {/* current exercise */}
      <Card className="p-4">
        <p className="text-[10px] font-bold uppercase tracking-widest text-flame">
          {t("exOf", { a: fmtInt(exIdx + 1), b: fmtInt(items.length) })} • {MUSCLE_LABELS[item.muscle][lang]}
        </p>
        <h2 className="mt-1 font-display text-2xl font-bold text-snow">{lang === "ar" ? item.nameAr : item.nameEn}</h2>
        <p className="mt-1.5 rounded-xl bg-coal p-3 text-xs leading-relaxed text-mist">
          <span className="me-1 font-bold text-flame">{t("technique")}:</span>
          {lang === "ar" ? item.cueAr : item.cueEn}
        </p>
        {(item.altAr || item.altEn) && (
          <p className="mt-1.5 text-[10px] leading-relaxed text-mist/70">
            <span className="font-bold text-mist">{t("saferAlt")}: </span>
            {lang === "ar" ? item.altAr : item.altEn}
          </p>
        )}
        <div className="mt-3 flex items-center justify-between">
          <p className="text-sm font-bold text-snow">
            {t("setOf", { a: fmtInt(curSetNo), b: fmtInt(P) })}
          </p>
          {session.reduced && <Chip tone="flame">{t("keepItLight")}</Chip>}
        </div>
        <div className="mt-1.5 flex gap-1">
          {Array.from({ length: P }, (_, i) => (
            <span key={i} className={`h-1.5 flex-1 rounded-full ${i < doneSetsFor(item.id) ? "bg-flame" : "bg-raised"}`} />
          ))}
        </div>
      </Card>

      {/* rest timer */}
      {resting && (
        <Card className="flex items-center gap-4 border-flame/40 p-4">
          <Ring value={restPct} size={72} stroke={7} color="#FF7A00">
            <span className="font-display text-lg font-bold tabular-nums text-flame">{restLeft}</span>
            <span className="text-[8px] text-mist">{t("seconds")}</span>
          </Ring>
          <div className="flex-1">
            <p className="font-display text-lg font-semibold text-snow">{t("restTimer")}</p>
            <p className="text-[11px] text-mist">{fmtInt(prescription.rest)} {t("seconds")}</p>
          </div>
          <Btn variant="ghost" className="!px-3 !py-2 text-xs" onClick={() => setRestEnds(null)}>
            <Icon name="skip" size={14} />
            {t("skipRest")}
          </Btn>
        </Card>
      )}

      {/* inputs */}
      <Card className="space-y-3 p-4">
        <div className="grid grid-cols-2 gap-2">
          <Field label={`${t("wPerDumbbell")} • ${t("wPerDumbbellNote")}`}>
            <NumInput value={weight} onChange={setWeight} min={0} max={100} step={0.5} placeholder="5" />
          </Field>
          {item.unilateral ? (
            <div className="grid grid-cols-2 gap-2">
              <Field label={t("leftArm")}>
                <NumInput value={repsL} onChange={setRepsL} min={0} max={50} />
              </Field>
              <Field label={t("rightArm")}>
                <NumInput value={repsR} onChange={setRepsR} min={0} max={50} />
              </Field>
            </div>
          ) : (
            <Field label={`${t("repsActual")} / ${t("repsTarget")}: ${fmtInt(prescription.hi)}`}>
              <NumInput value={reps} onChange={setReps} min={0} max={50} />
            </Field>
          )}
        </div>
        <Field label={t("rpe")}>
          <SelectInput
            value={rpe}
            onChange={setRpe}
            options={Array.from({ length: 10 }, (_, i) => String(i + 1)).map((v) => ({ value: v, label: v }))}
          />
        </Field>
        <div className="flex justify-between text-[9px] text-mist/60">
          <span>{t("rpeEasy")}</span>
          <span>{t("rpeHard")}</span>
        </div>
        <Field label={`${t("notes")} (${t("optional")})`}>
          <TextInput value={notes} onChange={setNotes} placeholder={t("notePh")} />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Btn onClick={() => completeSet(true)}>
            <Icon name="check" size={16} />
            {t("completeSet")}
          </Btn>
          <Btn variant="ghost" onClick={() => completeSet(false)}>
            {t("skipSet")}
          </Btn>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Btn variant="ghost" className="!py-2.5 text-xs" onClick={() => setExIdx(Math.max(0, exIdx - 1))} disabled={exIdx === 0}>
            {t("prevEx")}
          </Btn>
          <Btn
            variant={allDone ? "primary" : "soft"}
            className="!py-2.5 text-xs"
            onClick={() => (resting ? setRestEnds(null) : setFinishOpen(true))}
          >
            <Icon name="flag" size={14} />
            {t("finishW")}
          </Btn>
        </div>
      </Card>

      <SafetyCard t={t} />

      <Modal open={finishOpen} onClose={() => setFinishOpen(false)} title={t("finishTitle")}>
        <p className="text-sm text-mist">
          {t("finishMsg", { n: fmtInt(stats?.setsDone ?? 0) })}
        </p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <Btn variant="ghost" onClick={() => setFinishOpen(false)}>
            {t("cancel")}
          </Btn>
          <Btn onClick={finish}>
            <Icon name="check" size={15} />
            {t("done")}
          </Btn>
        </div>
      </Modal>
    </div>
  );
}

function SafetyCard({ t }: { t: (k: string) => string }) {
  return (
    <Card className="flex items-start gap-2.5 border-danger/25 p-3.5">
      <Icon name="alert" size={17} className="mt-0.5 shrink-0 text-danger" />
      <p className="text-[11px] leading-relaxed text-mist">{t("safetyLive")}</p>
    </Card>
  );
}
