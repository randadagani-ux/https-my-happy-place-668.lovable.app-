"use client";

import { useApp } from "@/lib/store";
import {
  itemsById,
  overloadSuggestions,
  sessionStats,
  startOfWeekSat,
  todayISO,
  weekCompletion,
} from "@/lib/calc";
import { phaseForWeek } from "@/lib/data";
import { Bar, Btn, Card, Chip, EmptyState, Icon, LineChart, Ring, SectionHead } from "@/components/ui";

export default function Home() {
  const { state, t, lang, fmtNum, fmtInt, fmtDate, week, prescription } = useApp();
  const today = todayISO();
  const p = state.profile;
  const phase = phaseForWeek(week);

  // Nutrition today
  const mealsToday = state.meals.filter((m) => m.date === today);
  const cal = mealsToday.reduce((a, m) => a + m.calories, 0);
  const prot = mealsToday.reduce((a, m) => a + m.proteinG, 0);
  const calPct = state.settings.calorieTarget > 0 ? cal / state.settings.calorieTarget : 0;
  const protPct = state.settings.proteinTarget > 0 ? prot / state.settings.proteinTarget : 0;

  // Weight
  const weights = [...state.weights].sort((a, b) => a.date.localeCompare(b.date));
  const latest = weights[weights.length - 1];
  const delta = latest ? latest.weightKg - p.startWeightKg : 0;

  // Today's planned day
  const dayIdx = new Date().getDay();
  const schedDay = state.schedule.find((d) => d.dayIndex === dayIdx);
  let type: string = schedDay && schedDay.enabled ? schedDay.type : "rest";
  if ((type === "A" || type === "B") && schedDay?.week3PlusOnly && week < 3) type = "recovery";
  const todaySession = state.sessions.find(
    (s) => s.date === today && s.planId === type && s.status !== "skipped"
  );

  const weekStart = startOfWeekSat(today);
  const comp = weekCompletion(state.sessions, state.schedule, weekStart, week);
  const items = itemsById(state);
  const sessStats = todaySession ? sessionStats(todaySession, items) : null;

  // Measurements
  const measSorted = [...state.measurements].sort((a, b) => a.date.localeCompare(b.date));
  const lastMeas = measSorted[measSorted.length - 1];
  const firstMeas = measSorted[0];
  const waistDelta = lastMeas?.waistCm != null && firstMeas?.waistCm != null ? lastMeas.waistCm - firstMeas.waistCm : null;

  // Sleep
  const sleepSorted = [...state.sleep].sort((a, b) => b.date.localeCompare(a.date));
  const lastSleep = sleepSorted[0];
  const avg3 =
    sleepSorted.length > 0
      ? sleepSorted.slice(0, 3).reduce((a, s) => a + s.hours, 0) / Math.min(3, sleepSorted.length)
      : 0;

  const sugg = overloadSuggestions(state);
  const walkToday = state.treadmill.filter((x) => x.date === today).reduce((a, x) => a + x.minutes, 0);

  const chartPoints = weights.slice(-10).map((w) => ({ label: fmtDate(w.date), value: w.weightKg }));

  return (
    <div className="space-y-3">
      {/* Welcome */}
      <div className="flex items-center justify-between gap-3 px-1 pt-2">
        <div>
          <h1 className="font-display text-2xl font-bold text-snow">{t("welcome", { name: p.name || "RNDFIT" })}</h1>
          <p className="mt-0.5 flex items-center gap-2 text-xs text-mist">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-flame" />
            {t("weekOf", { w: fmtInt(week) })} — {lang === "ar" ? phase.phaseAr : phase.phaseEn}
          </p>
        </div>
        <Chip tone="flame">{t("weekShort", { w: fmtInt(week) })}</Chip>
      </div>

      {/* Calorie ring + weight */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="flex flex-col items-center p-4">
          <Ring value={calPct} size={112} stroke={10}>
            <span className="font-display text-2xl font-bold text-flame">{fmtInt(calPct * 100)}%</span>
            <span className="text-[10px] text-mist">{t("dailyCalories")}</span>
          </Ring>
          <p className="mt-3 text-center text-xs text-mist">
            <span className="font-semibold text-snow">{fmtInt(cal)}</span> / {fmtInt(state.settings.calorieTarget)} {t("kcal")}
          </p>
        </Card>
        <Card className="flex flex-col justify-between p-4">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-mist">
            <Icon name="scale" size={15} className="text-flame" />
            {t("currentWeight")}
          </span>
          <div className="py-2 text-center">
            <p className="font-display text-4xl font-bold text-snow">
              {latest ? fmtNum(latest.weightKg) : "—"}
              <span className="ms-1 text-sm font-semibold text-mist">{t("kg")}</span>
            </p>
            {latest && (
              <p className={`mt-1 text-xs font-semibold ${delta <= 0 ? "text-flame" : "text-mist"}`}>
                {delta > 0 ? "+" : ""}
                {fmtNum(delta)} {t("kg")} {t("sinceStart")}
              </p>
            )}
          </div>
          <span className="text-center text-[10px] text-mist">
            {t("weekOf", { w: fmtInt(week) })}
          </span>
        </Card>
      </div>

      {/* Protein */}
      <Card className="p-4">
        <div className="mb-2 flex items-center justify-between text-xs">
          <span className="flex items-center gap-1.5 font-semibold text-snow">
            <Icon name="droplet" size={14} className="text-flame" />
            {t("protein")}
          </span>
          <span className="text-mist">
            {t("proteinOf", { v: fmtInt(prot), t: fmtInt(state.settings.proteinTarget) })}
          </span>
        </div>
        <Bar value={protPct} />
      </Card>

      {/* Today's workout */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-sm font-bold text-snow">
            <span className="grid size-8 place-items-center rounded-lg bg-flame/12 text-flame">
              <Icon name={type === "walk" ? "pulse" : type === "rest" || type === "recovery" ? "moon" : "dumbbell"} size={17} />
            </span>
            {t("todayWorkout")}
          </span>
          {type === "A" || type === "B" ? (
            todaySession?.status === "completed" ? (
              <Chip tone="ink">
                <Icon name="check" size={12} /> {t("completedChip")}
              </Chip>
            ) : todaySession?.status === "in-progress" ? (
              <Chip tone="flame">{t("inProgressChip")}</Chip>
            ) : (
              <Chip tone="mist">{t("notDone")}</Chip>
            )
          ) : type === "walk" ? (
            walkToday > 0 ? (
              <Chip tone="ink">{t("walkDoneChip", { m: fmtInt(walkToday) })}</Chip>
            ) : (
              <Chip tone="mist">{t("walkPendingChip")}</Chip>
            )
          ) : null}
        </div>
        <p className="mt-2 font-display text-xl font-semibold text-snow">
          {type === "A" && t("workoutA")}
          {type === "B" && t("workoutB")}
          {type === "walk" && t("walkDay")}
          {(type === "rest" || type === "recovery") && t("restDay")}
        </p>
        <p className="mt-0.5 text-xs text-mist">
          {type === "A" || type === "B"
            ? sessStats && todaySession
              ? `${t("totalSets")}: ${fmtInt(sessStats.setsDone)} • ${t("elapsed")}: ${fmtInt(sessStats.durationMin)} ${t("minutes")}`
              : t("prescriptionSub", { sets: fmtInt(prescription.sets), lo: fmtInt(prescription.lo), hi: fmtInt(prescription.hi), r: fmtInt(prescription.rest) })
            : type === "walk"
              ? t("walkDaySub")
              : t("restDaySub")}
        </p>
        {(type === "A" || type === "B") && (
          <Btn
            className="mt-3 w-full"
            onClick={() => {
              window.location.hash = `#/live/${type}`;
            }}
          >
            <Icon name="play" size={16} />
            {todaySession?.status === "in-progress" ? t("resume") : t("startNow")}
          </Btn>
        )}
        {type === "walk" && (
          <Btn variant="soft" className="mt-3 w-full" onClick={() => (window.location.hash = "#/workouts")}>
            <Icon name="pulse" size={16} />
            {t("logWalk")}
          </Btn>
        )}
        <p className="mt-3 border-t border-line pt-2 text-center text-[11px] text-mist">
          {t("thisWeekSessions", { d: fmtInt(comp.done), p: fmtInt(comp.planned) })} — {fmtInt(comp.pct)}%
        </p>
      </Card>

      {/* Weight trend */}
      <Card>
        <SectionHead title={t("weeklyProgress")} sub={t("lastWeeks")} icon="chart" />
        <div className="px-3 pb-3">
          {chartPoints.length >= 2 ? (
            <LineChart points={chartPoints} fmt={(n) => fmtNum(n)} />
          ) : (
            <EmptyState icon="scale" title={t("noData")} sub={t("noWeights")} />
          )}
        </div>
      </Card>

      {/* Shortcuts */}
      <div className="grid grid-cols-2 gap-3">
        <Card
          className="flex flex-col items-start gap-2 p-4"
          onClick={() => (window.location.hash = "#/schedule")}
        >
          <span className="grid size-10 place-items-center rounded-xl bg-flame text-ink">
            <Icon name="dumbbell" size={20} />
          </span>
          <span className="font-display text-base font-semibold text-snow">{t("dumbbells")}</span>
          <span className="text-[11px] text-mist">{t("dumbbellsSub")}</span>
        </Card>
        <Card
          className="flex flex-col items-start gap-2 p-4"
          onClick={() => (window.location.hash = "#/workouts")}
        >
          <span className="grid size-10 place-items-center rounded-xl bg-raised text-flame">
            <Icon name="pulse" size={20} />
          </span>
          <span className="font-display text-base font-semibold text-snow">{t("treadmill")}</span>
          <span className="text-[11px] text-mist">{t("treadmillSub")}</span>
        </Card>
      </div>

      {/* Measurements + sleep */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-mist">
            <Icon name="target" size={14} className="text-flame" />
            {t("measurements")}
          </span>
          {lastMeas ? (
            <div className="mt-2 space-y-1 text-xs">
              {lastMeas.waistCm != null && (
                <p className="flex justify-between">
                  <span className="text-mist">{t("waist")}</span>
                  <span className="font-semibold text-snow">
                    {fmtNum(lastMeas.waistCm)} {t("cm")}
                  </span>
                </p>
              )}
              {lastMeas.chestCm != null && (
                <p className="flex justify-between">
                  <span className="text-mist">{t("chest")}</span>
                  <span className="font-semibold text-snow">
                    {fmtNum(lastMeas.chestCm)} {t("cm")}
                  </span>
                </p>
              )}
              {lastMeas.thighCm != null && (
                <p className="flex justify-between">
                  <span className="text-mist">{t("thigh")}</span>
                  <span className="font-semibold text-snow">
                    {fmtNum(lastMeas.thighCm)} {t("cm")}
                  </span>
                </p>
              )}
              {waistDelta != null && (
                <p className="pt-1 font-semibold text-flame">
                  {waistDelta > 0 ? "+" : ""}
                  {fmtNum(waistDelta)} {t("cm")} {t("firstEntry")}
                </p>
              )}
            </div>
          ) : (
            <p className="mt-2 text-[11px] text-mist">{t("noMeasure")}</p>
          )}
        </Card>
        <Card className="p-4">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-mist">
            <Icon name="moon" size={14} className="text-flame" />
            {t("sleep")}
          </span>
          {lastSleep ? (
            <div className="mt-2 space-y-1.5 text-xs">
              <p className="flex justify-between">
                <span className="text-mist">{t("lastNight")}</span>
                <span className="font-semibold text-snow">
                  {fmtNum(lastSleep.hours)} {t("hours")}
                </span>
              </p>
              <p className="flex justify-between">
                <span className="text-mist">{t("quality")}</span>
                <span className="font-semibold text-flame">{"●".repeat(lastSleep.quality)}{"○".repeat(5 - lastSleep.quality)}</span>
              </p>
              <p className="flex justify-between">
                <span className="text-mist">{t("avg3")}</span>
                <span className="font-semibold text-snow">{fmtNum(avg3)} {t("hours")}</span>
              </p>
            </div>
          ) : (
            <p className="mt-2 text-[11px] text-mist">{t("noSleep")}</p>
          )}
        </Card>
      </div>

      {/* Suggestion banner */}
      {sugg.length > 0 && (
        <Card className="border-flame/40 bg-flame/8 p-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="grid size-9 place-items-center rounded-xl bg-flame text-ink">
                <Icon name="flame" size={18} />
              </span>
              <div>
                <p className="text-sm font-bold text-snow">{t("suggestion")}</p>
                <p className="text-[11px] text-mist">{t("suggestionSub", { n: fmtInt(sugg.length) })}</p>
              </div>
            </div>
            <Btn variant="primary" className="!px-3 !py-2 text-xs" onClick={() => (window.location.hash = "#/reports")}>
              {t("viewReports")}
            </Btn>
          </div>
        </Card>
      )}
    </div>
  );
}
