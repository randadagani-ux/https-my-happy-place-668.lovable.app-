"use client";

import { useRef, useState } from "react";
import { useApp } from "@/lib/store";
import { buildCsv, todayISO } from "@/lib/calc";
import type { Goal } from "@/lib/types";
import { Btn, Card, DateInput, Field, Icon, Logo, Modal, NumInput, SectionHead, Segmented, TextInput, Wordmark, downloadFile } from "@/components/ui";

export default function More() {
  const { state, t, lang, fmtInt, setLang, updateProfile, updateSettings, exportData, importData, resetAll } = useApp();
  const p = state.profile;
  const [name, setName] = useState(p.name);
  const [goal, setGoal] = useState<Goal>(p.goal);
  const [sw, setSw] = useState(String(p.startWeightKg));
  const [tw, setTw] = useState(String(p.targetWeightKg));
  const [ht, setHt] = useState(String(p.heightCm));
  const [sd, setSd] = useState(p.startDate);
  const [resetOpen, setResetOpen] = useState(false);
  const [importMsg, setImportMsg] = useState<"ok" | "bad" | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const saveProfile = () => {
    updateProfile({
      name: name.trim() || p.name,
      goal,
      startWeightKg: parseFloat(sw) || p.startWeightKg,
      targetWeightKg: parseFloat(tw) || p.targetWeightKg,
      heightCm: parseFloat(ht) || p.heightCm,
      startDate: sd || p.startDate,
    });
  };

  const doImport = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const ok = importData(String(reader.result ?? ""));
      setImportMsg(ok ? "ok" : "bad");
      setTimeout(() => setImportMsg(null), 3000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-3">
      <div className="px-1 pt-2">
        <h1 className="font-display text-2xl font-bold text-snow">{t("more")}</h1>
      </div>

      {/* Profile */}
      <Card>
        <SectionHead title={t("profile")} icon="runner" />
        <div className="space-y-2 px-4 pb-4">
          <Field label={t("name")}>
            <TextInput value={name} onChange={setName} placeholder={t("obNamePh")} />
          </Field>
          <Field label={t("obGoal")}>
            <Segmented
              value={goal}
              onChange={setGoal}
              options={[
                { value: "lose", label: t("goalLose") },
                { value: "build", label: t("goalBuild") },
                { value: "both", label: t("goalBoth") },
              ]}
            />
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label={t("obStartW")}>
              <NumInput value={sw} onChange={setSw} min={20} max={300} />
            </Field>
            <Field label={t("obTargetW")}>
              <NumInput value={tw} onChange={setTw} min={20} max={300} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Field label={t("obHeight")}>
              <NumInput value={ht} onChange={setHt} min={100} max={230} />
            </Field>
            <Field label={t("obStartD")}>
              <DateInput value={sd} onChange={setSd} />
            </Field>
          </div>
          <Btn className="w-full !py-2.5 text-xs" onClick={saveProfile}>
            <Icon name="check" size={14} />
            {t("save")}
          </Btn>
        </div>
      </Card>

      {/* Language */}
      <Card>
        <SectionHead title={t("language")} icon="edit" />
        <div className="grid grid-cols-2 gap-2 px-4 pb-4">
          <button
            onClick={() => setLang("en")}
            className={`rounded-xl border py-3 text-sm font-bold transition ${
              lang === "en" ? "border-flame bg-flame text-ink" : "border-line bg-coal text-snow"
            }`}
          >
            English
          </button>
          <button
            onClick={() => setLang("ar")}
            className={`rounded-xl border py-3 text-sm font-bold transition ${
              lang === "ar" ? "border-flame bg-flame text-ink" : "border-line bg-coal text-snow"
            }`}
          >
            العربية
          </button>
        </div>
      </Card>

      {/* Training prefs */}
      <Card>
        <SectionHead title={t("trainingPrefs")} icon="dumbbell" />
        <div className="space-y-4 px-4 pb-4">
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="font-medium text-mist">{t("restBetween")}</span>
              <span className="font-bold text-flame">
                {fmtInt(state.settings.restSeconds)} {t("seconds")}
              </span>
            </div>
            <input
              type="range"
              min={30}
              max={180}
              step={15}
              value={state.settings.restSeconds}
              onChange={(e) => updateSettings({ restSeconds: parseInt(e.target.value, 10) })}
              className="w-full"
            />
          </div>
          <Field label={t("setsPerEx")}>
            <Segmented
              value={String(state.settings.setsPerExercise)}
              onChange={(v) => updateSettings({ setsPerExercise: parseInt(v, 10) })}
              options={[
                { value: "1", label: "1" },
                { value: "2", label: "2" },
                { value: "3", label: "3" },
              ]}
            />
          </Field>
          <Field label={t("weightConv")} hint={t("weightConvNote")}>
            <Segmented
              value={state.settings.weightConvention}
              onChange={(v) => updateSettings({ weightConvention: v })}
              options={[
                { value: "per", label: t("perDumbbell") },
                { value: "combined", label: t("combined") },
              ]}
            />
          </Field>
        </div>
      </Card>

      {/* Backup */}
      <Card>
        <SectionHead title={t("backup")} icon="download" />
        <div className="space-y-2 px-4 pb-4">
          <Btn
            variant="ghost"
            className="w-full !py-2.5 text-xs"
            onClick={() => downloadFile(`rndfit-backup-${todayISO()}.json`, exportData(), "application/json")}
          >
            <Icon name="download" size={15} className="text-flame" />
            {t("exportJson")}
          </Btn>
          <Btn variant="ghost" className="w-full !py-2.5 text-xs" onClick={() => fileRef.current?.click()}>
            <Icon name="upload" size={15} className="text-flame" />
            {t("importJson")}
          </Btn>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) doImport(f);
              e.target.value = "";
            }}
          />
          <Btn
            variant="ghost"
            className="w-full !py-2.5 text-xs"
            onClick={() => downloadFile(`rndfit-workouts-${todayISO()}.csv`, buildCsv(state), "text/csv")}
          >
            <Icon name="chart" size={15} className="text-flame" />
            {t("exportCsv")}
          </Btn>
          {importMsg && (
            <p className={`text-center text-xs font-semibold ${importMsg === "ok" ? "text-flame" : "text-danger"}`}>
              {importMsg === "ok" ? t("importOk") : t("importBad")}
            </p>
          )}
          <Btn variant="danger" className="w-full !py-2.5 text-xs" onClick={() => setResetOpen(true)}>
            <Icon name="trash" size={15} />
            {t("resetAll")}
          </Btn>
        </div>
      </Card>

      {/* Safety */}
      <Card>
        <SectionHead title={t("safety")} icon="alert" />
        <ul className="space-y-2 px-4 pb-4 text-xs leading-relaxed text-mist">
          {[t("safety1"), t("safety2"), t("safety3")].map((s, i) => (
            <li key={i} className="flex gap-2">
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-flame" />
              {s}
            </li>
          ))}
        </ul>
      </Card>

      {/* About */}
      <Card className="flex flex-col items-center gap-2 p-6 text-center">
        <Logo size={56} />
        <Wordmark className="text-2xl" />
        <p className="text-xs font-semibold text-flame">{t("sloganAr")}</p>
        <p className="text-[10px] tracking-[0.25em] text-mist">{t("sloganEn")}</p>
        <p className="mt-1 text-[10px] text-mist/80">{t("aboutText")}</p>
      </Card>

      <Modal open={resetOpen} onClose={() => setResetOpen(false)} title={t("resetTitle")}>
        <p className="text-sm leading-relaxed text-mist">{t("resetMsg")}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <Btn variant="ghost" onClick={() => setResetOpen(false)}>
            {t("cancel")}
          </Btn>
          <Btn
            variant="danger"
            onClick={() => {
              resetAll();
              setResetOpen(false);
              window.location.hash = "#/home";
            }}
          >
            {t("resetYes")}
          </Btn>
        </div>
      </Modal>
    </div>
  );
}
