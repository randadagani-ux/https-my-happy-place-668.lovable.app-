"use client";

import { useState } from "react";
import { useApp } from "@/lib/store";
import { todayISO } from "@/lib/calc";
import type { MealCategory } from "@/lib/types";
import { Bar, Btn, Card, Chip, DateInput, Field, Icon, NumInput, SectionHead, SelectInput, TextInput } from "@/components/ui";

const CATS: MealCategory[] = ["breakfast", "lunch", "dinner", "snack"];

export default function Nutrition() {
  const { state, t, fmtInt, fmtNum, fmtDate, addMeal, removeMeal, updateSettings } = useApp();
  const [date, setDate] = useState(todayISO());
  const [cat, setCat] = useState<MealCategory>("breakfast");
  const [food, setFood] = useState("");
  const [kcal, setKcal] = useState("");
  const [protV, setProtV] = useState("");
  const [calTarget, setCalTarget] = useState(String(state.settings.calorieTarget));
  const [protTarget, setProtTarget] = useState(String(state.settings.proteinTarget));

  const dayMeals = state.meals.filter((m) => m.date === date);
  const cal = dayMeals.reduce((a, m) => a + m.calories, 0);
  const prot = dayMeals.reduce((a, m) => a + m.proteinG, 0);
  const calLeft = state.settings.calorieTarget - cal;
  const protLeft = state.settings.proteinTarget - prot;

  const save = () => {
    const name = food.trim();
    const k = parseInt(kcal, 10) || 0;
    if (!name && k === 0) return;
    addMeal({ date, category: cat, name: name || t(cat), calories: k, proteinG: parseInt(protV, 10) || 0 });
    setFood("");
    setKcal("");
    setProtV("");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2 px-1 pt-2">
        <h1 className="font-display text-2xl font-bold text-snow">{t("nutrition")}</h1>
        <div className="w-36">
          <DateInput value={date} onChange={setDate} />
        </div>
      </div>

      {/* Targets */}
      <Card>
        <SectionHead title={t("targets")} icon="target" />
        <div className="grid grid-cols-2 gap-2 px-4 pb-4">
          <Field label={t("calories")}>
            <NumInput value={calTarget} onChange={setCalTarget} min={500} max={6000} />
          </Field>
          <Field label={t("proteinG")}>
            <NumInput value={protTarget} onChange={setProtTarget} min={20} max={400} />
          </Field>
          <Btn
            className="col-span-2 !py-2.5 text-xs"
            onClick={() =>
              updateSettings({
                calorieTarget: Math.max(500, parseInt(calTarget, 10) || 0),
                proteinTarget: Math.max(20, parseInt(protTarget, 10) || 0),
              })
            }
          >
            <Icon name="check" size={14} />
            {t("save")}
          </Btn>
        </div>
      </Card>

      {/* Intake */}
      <Card className="p-4">
        <p className="mb-3 flex items-center gap-2 text-sm font-bold text-snow">
          <Icon name="flame" size={16} className="text-flame" />
          {t("dailyIntake")} — {fmtDate(date, "medium")}
        </p>
        <div className="space-y-3">
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-mist">
                {t("calories")}: <span className="font-semibold text-snow">{fmtInt(cal)}</span> / {fmtInt(state.settings.calorieTarget)}
              </span>
              {calLeft >= 0 ? (
                <span className="text-mist">{t("remaining", { v: fmtInt(calLeft) })}</span>
              ) : (
                <span className="text-danger">{t("overTarget", { v: fmtInt(-calLeft) })}</span>
              )}
            </div>
            <Bar value={state.settings.calorieTarget > 0 ? cal / state.settings.calorieTarget : 0} />
          </div>
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-mist">
                {t("protein")}: <span className="font-semibold text-snow">{fmtInt(prot)}</span> / {fmtInt(state.settings.proteinTarget)} {t("grams")}
              </span>
              {protLeft >= 0 ? (
                <span className="text-mist">{t("remaining", { v: fmtInt(protLeft) })}</span>
              ) : (
                <span className="text-danger">{t("overTarget", { v: fmtInt(-protLeft) })}</span>
              )}
            </div>
            <Bar value={state.settings.proteinTarget > 0 ? prot / state.settings.proteinTarget : 0} />
          </div>
        </div>
      </Card>

      {/* Add meal */}
      <Card>
        <SectionHead title={t("addMeal")} icon="utensils" />
        <div className="space-y-2 px-4 pb-4">
          <div className="grid grid-cols-2 gap-2">
            <Field label={t("meal")}>
              <SelectInput
                value={cat}
                onChange={(v) => setCat(v as MealCategory)}
                options={CATS.map((c) => ({ value: c, label: t(c) }))}
              />
            </Field>
            <Field label={t("foodName")}>
              <TextInput value={food} onChange={setFood} placeholder="…" />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Field label={t("kcal")}>
              <NumInput value={kcal} onChange={setKcal} min={0} />
            </Field>
            <Field label={t("grams")}>
              <NumInput value={protV} onChange={setProtV} min={0} />
            </Field>
          </div>
          <Btn className="w-full !py-2.5 text-xs" onClick={save}>
            <Icon name="plus" size={14} />
            {t("add")}
          </Btn>
        </div>
      </Card>

      {/* Diary */}
      <Card>
        <SectionHead
          title={t("dailyIntake")}
          sub={`${fmtInt(dayMeals.length)} • ${fmtInt(cal)} ${t("kcal")}`}
          icon="utensils"
        />
        <div className="px-4 pb-4">
          {CATS.map((c) => {
            const list = dayMeals.filter((m) => m.category === c);
            if (list.length === 0) return null;
            return (
              <div key={c} className="mb-3 last:mb-0">
                <p className="mb-1.5 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-flame">
                  {t(c)}
                  <span className="text-mist/70">
                    {fmtInt(list.reduce((a, m) => a + m.calories, 0))} {t("kcal")}
                  </span>
                </p>
                <div className="space-y-1.5">
                  {list.map((m) => (
                    <div key={m.id} className="flex items-center justify-between rounded-lg bg-coal px-3 py-2 text-xs">
                      <span className="min-w-0 flex-1 truncate text-snow">{m.name || t(m.category)}</span>
                      <span className="ms-2 shrink-0 tabular-nums text-mist">
                        {fmtInt(m.calories)} {t("kcal")}
                        {m.proteinG > 0 && (
                          <>
                            {" • "}
                            {fmtNum(m.proteinG)} {t("grams")}
                          </>
                        )}
                      </span>
                      <button onClick={() => removeMeal(m.id)} className="ms-2 shrink-0 text-mist hover:text-danger" aria-label={t("delete")}>
                        <Icon name="trash" size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {dayMeals.length === 0 && (
            <div className="flex flex-col items-center gap-2 py-6 text-center">
              <Chip tone="mist">{t("today")}</Chip>
              <p className="text-[11px] text-mist">{t("emptyDay")}</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
