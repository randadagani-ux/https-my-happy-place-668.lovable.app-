"use client";

import { useState } from "react";
import { useApp } from "@/lib/store";
import {
  dateForWeekDay,
  plannedStrengthDays,
  sessionForDay,
  sessionStats,
  startOfWeekSat,
  todayISO,
  weekCompletion,
} from "@/lib/calc";
import type { ScheduleDay, ScheduleDayType } from "@/lib/types";
import { Btn, Card, Chip, Icon, Ring, SelectInput } from "@/components/ui";

function typeLabel(ty: string, t: (k: string, v?: Record<string, string | number>) => string) {
  if (ty === "A") return t("typeA");
  if (ty === "B") return t("typeB");
  if (ty === "walk") return t("typeWalk");
  if (ty === "recovery") return t("typeRecovery");
  return t("typeRest");
}

export default function Schedule() {
  const { state, t, lang, fmtInt, fmtWeekday, week, addSkippedSession, setScheduleDay } = useApp();
  const [editing, setEditing] = useState(false);
  const today = todayISO();
  const weekStart = startOfWeekSat(today);

  const comp = weekCompletion(state.sessions, state.schedule, weekStart, week);
  const planned = plannedStrengthDays(state.schedule, week);
  const items = state.customWorkouts;

  const typeIcon = (ty: string) => (ty === "A" || ty === "B" ? "dumbbell" : ty === "walk" ? "pulse" : ty === "recovery" ? "refresh" : "moon");

  return (
    <div className="space-y-3">
      <div className="px-1 pt-2">
        <h1 className="font-display text-2xl font-bold text-snow">{t("schedTitle")}</h1>
        <p className="mt-0.5 text-xs text-mist">{t("schedSub")}</p>
      </div>

      {/* Week summary */}
      <Card className="flex items-center gap-4 p-4">
        <Ring value={comp.planned > 0 ? comp.done / comp.planned : 0} size={84} stroke={8}>
          <span className="font-display text-lg font-bold text-flame">{fmtInt(comp.pct)}%</span>
          <span className="text-[8px] text-mist">{t("completion")}</span>
        </Ring>
        <div className="flex-1">
          <p className="font-display text-lg font-semibold text-snow">
            {t("weekOf", { w: fmtInt(week) })}
          </p>
          <p className="text-xs text-mist">
            {t("sessions", { d: fmtInt(comp.done), p: fmtInt(comp.planned) })}
          </p>
          <div className="mt-2 flex flex-wrap gap-1">
            {planned.map((d) => {
              const s = sessionForDay(state.sessions, weekStart, d);
              const done = s?.status === "completed";
              const skipped = s?.status === "skipped";
              return (
                <Chip key={d.key} tone={done ? "ink" : skipped ? "danger" : "mist"}>
                  {fmtWeekday(dateForWeekDay(weekStart, d))}
                  {done && <Icon name="check" size={11} />}
                </Chip>
              );
            })}
          </div>
        </div>
      </Card>

      {/* Days */}
      <div className="space-y-2">
        {state.schedule.map((day) => {
          const dateISO = dateForWeekDay(weekStart, day);
          const isToday = dateISO === today;
          const isFuture = dateISO > today;
          const blocked = day.week3PlusOnly && week < 3;
          const showAsRecovery = (day.type === "A" || day.type === "B") && blocked && !isFuture;

          const pid: "A" | "B" | null =
            day.type === "A" || day.type === "B" ? day.type : null;
          const sess =
            day.type === "A" || day.type === "B" ? sessionForDay(state.sessions, weekStart, day) : null;
          const walkEntry = state.treadmill.find((x) => x.date === dateISO);

          let statusChip: React.ReactNode = null;
          if (!day.enabled) {
            statusChip = <Chip tone="mist">{t("disabledDay")}</Chip>;
          } else if (showAsRecovery) {
            statusChip = <Chip tone="mist">{t("typeRecovery")}</Chip>;
          } else if (day.type === "A" || day.type === "B") {
            if (sess?.status === "completed")
              statusChip = (
                <Chip tone="ink">
                  <Icon name="check" size={11} />
                  {t("completedChip")}
                </Chip>
              );
            else if (sess?.status === "in-progress") statusChip = <Chip tone="flame">{t("inProgressChip")}</Chip>;
            else if (sess?.status === "skipped") statusChip = <Chip tone="danger">{t("skippedChip")}</Chip>;
            else statusChip = <Chip tone="mist">{t("pendingChip")}</Chip>;
          } else if (day.type === "walk") {
            statusChip = walkEntry ? (
              <Chip tone="ink">
                <Icon name="check" size={11} />
                {t("walkDoneChip", { m: fmtInt(walkEntry.minutes) })}
              </Chip>
            ) : (
              <Chip tone="mist">{t("walkPendingChip")}</Chip>
            );
          }

          const desc =
            day.type === "A" || day.type === "B"
              ? t("exercisesCount", { n: fmtInt(items[day.type].length) })
              : day.type === "walk"
                ? t("walkDesc")
                : day.type === "recovery"
                  ? t("recoveryDesc")
                  : t("restDesc");

          return (
            <Card
              key={day.key}
              className={`p-3.5 ${isToday ? "border-flame/60" : ""} ${day.enabled ? "" : "opacity-60"}`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`grid size-10 shrink-0 place-items-center rounded-xl ${
                    day.type === "A" || day.type === "B" ? "bg-flame text-ink" : "bg-raised text-mist"
                  }`}
                >
                  <Icon name={typeIcon(day.type) as "dumbbell"} size={19} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2 text-sm font-bold text-snow">
                    <span className="truncate">{fmtWeekday(dateISO)}</span>
                    {isToday && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-flame" />}
                  </p>
                  <p className="text-[11px] text-mist">
                    {showAsRecovery ? t("wedNotYet") : typeLabel(day.type, t)}
                    {day.enabled && !showAsRecovery ? ` • ${desc}` : ""}
                  </p>
                </div>
                {statusChip}
              </div>

              {editing ? (
                <div className="mt-3 grid grid-cols-[1fr_auto] items-center gap-2 border-t border-line pt-3">
                  <SelectInput
                    value={day.type}
                    onChange={(v) => setScheduleDay(day.key, { type: v as ScheduleDayType })}
                    options={[
                      { value: "A", label: t("typeA") },
                      { value: "B", label: t("typeB") },
                      { value: "walk", label: t("typeWalk") },
                      { value: "recovery", label: t("typeRecovery") },
                      { value: "rest", label: t("typeRest") },
                    ]}
                  />
                  <button
                    onClick={() => setScheduleDay(day.key, { enabled: !day.enabled })}
                    className={`rounded-xl border px-3 py-2.5 text-xs font-bold transition ${
                      day.enabled ? "border-flame/50 bg-flame/15 text-flame" : "border-line bg-coal text-mist"
                    }`}
                  >
                    {t("enabled")}
                  </button>
                </div>
              ) : (
                pid !== null &&
                day.enabled &&
                (showAsRecovery ? (
                  <div className="mt-3 border-t border-line pt-3">
                    <p className="mb-2 text-[10px] text-mist/80">{t("wedNote")}</p>
                    <div className="grid grid-cols-2 gap-2">
                      <Btn variant="soft" className="!py-2 text-xs" onClick={() => (window.location.hash = `#/live/${pid}`)}>
                        <Icon name="play" size={13} />
                        {sess?.status === "in-progress" ? t("resume") : t("start")}
                      </Btn>
                      <Btn variant="ghost" className="!py-2 text-xs" onClick={() => addSkippedSession(pid, dateISO)}>
                        {t("skipSession")}
                      </Btn>
                    </div>
                  </div>
                ) : sess?.status === "completed" || sess?.status === "skipped" ? null : (
                  <div className="mt-3 grid grid-cols-2 gap-2 border-t border-line pt-3">
                    <Btn className="!py-2 text-xs" onClick={() => (window.location.hash = `#/live/${pid}`)}>
                      <Icon name="play" size={13} />
                      {sess?.status === "in-progress" ? t("resume") : t("start")}
                    </Btn>
                    <Btn variant="ghost" className="!py-2 text-xs" onClick={() => addSkippedSession(pid, dateISO)}>
                      {t("skipSession")}
                    </Btn>
                  </div>
                ))
              )}
            </Card>
          );
        })}
      </div>

      <div className="flex items-center justify-between px-1">
        <p className="max-w-[70%] text-[10px] leading-relaxed text-mist/80">{t("schedHint")}</p>
        <Btn variant={editing ? "soft" : "ghost"} className="!px-3 !py-2 text-xs" onClick={() => setEditing(!editing)}>
          <Icon name={editing ? "check" : "edit"} size={14} />
          {editing ? t("finishEdit") : t("editDays")}
        </Btn>
      </div>
    </div>
  );
}
