"use client";

import { useState } from "react";
import { useApp } from "@/lib/store";
import { addDaysISO, todayISO } from "@/lib/calc";
import { BarsChart, Btn, Card, Chip, DateInput, EmptyState, Field, Icon, LineChart, NumInput, Scale, SectionHead } from "@/components/ui";

const MEAS_KEYS = ["chest", "waist", "hip", "arm", "thigh"] as const;

export default function Progress() {
  const { state, t, lang, fmtNum, fmtInt, fmtDate, addWeight, removeWeight, addMeasurement, removeMeasurement, addSleep, removeSleep } = useApp();

  // weight form
  const [wDate, setWDate] = useState(todayISO());
  const [wKg, setWKg] = useState("");
  // measurement form
  const [mDate, setMDate] = useState(todayISO());
  const [mVals, setMVals] = useState<Record<string, string>>({});
  // sleep form
  const [sDate, setSDate] = useState(addDaysISO(todayISO(), -1));
  const [sHours, setSHours] = useState("7.5");
  const [sQual, setSQual] = useState(3);

  const weights = [...state.weights].sort((a, b) => a.date.localeCompare(b.date));
  const latest = weights[weights.length - 1];
  const delta = latest ? latest.weightKg - state.profile.startWeightKg : 0;
  const toGoal = latest ? state.profile.targetWeightKg - latest.weightKg : 0;
  const wChart = weights.slice(-12).map((w) => ({ label: fmtDate(w.date), value: w.weightKg }));

  const meas = [...state.measurements].sort((a, b) => a.date.localeCompare(b.date));
  const lastM = meas[meas.length - 1];
  const firstM = meas[0];

  const sleep = [...state.sleep].sort((a, b) => a.date.localeCompare(b.date)).slice(-14);
  const avg = state.sleep.length > 0 ? state.sleep.reduce((a, s) => a + s.hours, 0) / state.sleep.length : 0;

  const saveWeight = () => {
    const kg = parseFloat(wKg);
    if (!kg || kg <= 0) return;
    addWeight(wDate, kg);
    setWKg("");
  };

  const saveMeas = () => {
    const val = (k: string) => {
      const v = mVals[k] ? parseFloat(mVals[k]) : null;
      return v && isFinite(v) ? v : null;
    };
    const chest = val("chest");
    const waist = val("waist");
    const hip = val("hip");
    const arm = val("arm");
    const thigh = val("thigh");
    if (chest == null && waist == null && hip == null && arm == null && thigh == null) return;
    addMeasurement({ date: mDate, chestCm: chest, waistCm: waist, hipCm: hip, armCm: arm, thighCm: thigh });
    setMVals({});
  };

  const saveSleep = () => {
    const h = parseFloat(sHours);
    if (!h || h <= 0) return;
    addSleep({ date: sDate, hours: h, quality: sQual });
  };

  return (
    <div className="space-y-3">
      <div className="px-1 pt-2">
        <h1 className="font-display text-2xl font-bold text-snow">{t("progress")}</h1>
      </div>

      {/* Weight */}
      <Card>
        <SectionHead title={t("weight")} icon="scale" />
        <div className="px-4 pb-4">
          {latest ? (
            <div className="mb-3 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-xl bg-coal p-2.5">
                <p className="text-[10px] text-mist">{t("latest")}</p>
                <p className="font-display text-xl font-bold text-snow">
                  {fmtNum(latest.weightKg)} <span className="text-xs text-mist">{t("kg")}</span>
                </p>
              </div>
              <div className="rounded-xl bg-coal p-2.5">
                <p className="text-[10px] text-mist">{t("sinceStart")}</p>
                <p className={`font-display text-xl font-bold ${delta <= 0 ? "text-flame" : "text-snow"}`}>
                  {delta > 0 ? "+" : ""}
                  {fmtNum(delta)}
                </p>
              </div>
              <div className="rounded-xl bg-coal p-2.5">
                <p className="text-[10px] text-mist">{t("toGoal")}</p>
                <p className="font-display text-xl font-bold text-snow">{fmtNum(toGoal)}</p>
              </div>
            </div>
          ) : null}
          {wChart.length >= 2 ? (
            <LineChart points={wChart} fmt={(n) => fmtNum(n)} />
          ) : (
            <EmptyState icon="scale" title={t("noData")} sub={t("noWeights")} />
          )}
          <div className="mt-3 grid grid-cols-[1fr_1fr_auto] items-end gap-2">
            <Field label={t("date")}>
              <DateInput value={wDate} onChange={setWDate} />
            </Field>
            <Field label={t("kg")}>
              <NumInput value={wKg} onChange={setWKg} min={20} max={300} />
            </Field>
            <Btn className="!py-2.5 text-xs" onClick={saveWeight}>
              <Icon name="plus" size={14} />
            </Btn>
          </div>
          {weights.length > 0 && (
            <div className="mt-3 max-h-40 space-y-1.5 overflow-y-auto pe-1">
              {weights
                .slice()
                .reverse()
                .map((w) => (
                  <div key={w.id} className="flex items-center justify-between rounded-lg bg-coal px-3 py-2 text-xs">
                    <span className="text-mist">{fmtDate(w.date, "medium")}</span>
                    <span className="font-semibold text-snow">
                      {fmtNum(w.weightKg)} {t("kg")}
                    </span>
                    <button onClick={() => removeWeight(w.id)} className="text-mist hover:text-danger" aria-label={t("delete")}>
                      <Icon name="trash" size={14} />
                    </button>
                  </div>
                ))}
            </div>
          )}
        </div>
      </Card>

      {/* Measurements */}
      <Card>
        <SectionHead title={t("measurements")} icon="target" />
        <div className="px-4 pb-4">
          {lastM ? (
            <div className="mb-3 grid grid-cols-5 gap-1.5">
              {MEAS_KEYS.map((k) => {
                const v = lastM[`${k}Cm`] as number | null;
                const fv = firstM ? (firstM[`${k}Cm`] as number | null) : null;
                const d = v != null && fv != null && v !== fv ? v - fv : null;
                return (
                  <div key={k} className="rounded-xl bg-coal p-2 text-center">
                    <p className="truncate text-[9px] text-mist">{t(k)}</p>
                    <p className="font-display text-base font-bold text-snow">{v != null ? fmtNum(v) : "—"}</p>
                    {d != null && <p className={`text-[9px] font-semibold ${d <= 0 ? "text-flame" : "text-mist"}`}>{d > 0 ? "+" : ""}{fmtNum(d)}</p>}
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="mb-3 text-[11px] text-mist">{t("noMeasurements")}</p>
          )}
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-3">
              <DateInput value={mDate} onChange={setMDate} />
            </div>
            {MEAS_KEYS.map((k) => (
              <Field key={k} label={`${t(k)} (${t("cm")})`}>
                <NumInput
                  value={mVals[k] ?? ""}
                  onChange={(v) => setMVals((s) => ({ ...s, [k]: v }))}
                  placeholder="—"
                />
              </Field>
            ))}
          </div>
          <Btn className="mt-2 w-full !py-2.5 text-xs" onClick={saveMeas}>
            <Icon name="plus" size={14} />
            {t("addMeasurement")}
          </Btn>
          {meas.length > 0 && (
            <div className="mt-3 max-h-32 space-y-1.5 overflow-y-auto pe-1">
              {meas
                .slice()
                .reverse()
                .map((m) => (
                  <div key={m.id} className="flex items-center justify-between rounded-lg bg-coal px-3 py-2 text-[11px]">
                    <span className="text-mist">{fmtDate(m.date, "medium")}</span>
                    <span className="tabular-nums text-snow">
                      {MEAS_KEYS.map((k) => {
                        const v = m[`${k}Cm`] as number | null;
                        return v != null ? `${t(k)}: ${fmtNum(v)}` : null;
                      })
                        .filter(Boolean)
                        .join(" • ") || "—"}
                    </span>
                    <button onClick={() => removeMeasurement(m.id)} className="ms-2 text-mist hover:text-danger" aria-label={t("delete")}>
                      <Icon name="trash" size={13} />
                    </button>
                  </div>
                ))}
            </div>
          )}
        </div>
      </Card>

      {/* Sleep */}
      <Card>
        <SectionHead
          title={t("sleepTitle")}
          sub={`${t("avg3")}: ${fmtNum(avg)} ${t("hours")}`}
          icon="moon"
        />
        <div className="px-4 pb-4">
          {sleep.length >= 2 ? (
            <BarsChart
              items={sleep.map((s) => ({ label: fmtDate(s.date), value: s.hours }))}
              fmt={(n) => fmtNum(n)}
            />
          ) : (
            <EmptyState icon="moon" title={t("noData")} sub={t("noSleepData")} />
          )}
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Field label={t("date")}>
              <DateInput value={sDate} onChange={setSDate} />
            </Field>
            <Field label={`${t("hours")}`}>
              <NumInput value={sHours} onChange={setSHours} min={0} max={16} step={0.5} />
            </Field>
          </div>
          <div className="mt-2">
            <p className="mb-1.5 text-xs font-medium text-mist">{t("quality")}</p>
            <Scale value={sQual} onChange={setSQual} low={t("q1")} high={t("q5")} />
          </div>
          <Btn className="mt-2 w-full !py-2.5 text-xs" onClick={saveSleep}>
            <Icon name="plus" size={14} />
            {t("addSleep")}
          </Btn>
          {state.sleep.length > 0 && (
            <div className="mt-3 max-h-32 space-y-1.5 overflow-y-auto pe-1">
              {[...state.sleep]
                .sort((a, b) => b.date.localeCompare(a.date))
                .map((s) => (
                  <div key={s.id} className="flex items-center justify-between rounded-lg bg-coal px-3 py-2 text-[11px]">
                    <span className="text-mist">{fmtDate(s.date, "medium")}</span>
                    <span className="font-semibold text-snow">
                      {fmtNum(s.hours)} {t("hours")}
                    </span>
                    <Chip tone="flame">{lang === "ar" ? ["", "سيئة", "متوسطة", "جيدة", "ممتازة", "ممتازة"][s.quality] : ["", "Poor", "Okay", "Okay", "Good", "Excellent"][s.quality]}</Chip>
                    <button onClick={() => removeSleep(s.id)} className="text-mist hover:text-danger" aria-label={t("delete")}>
                      <Icon name="trash" size={13} />
                    </button>
                  </div>
                ))}
            </div>
          )}
        </div>
      </Card>

      <Btn variant="ghost" className="w-full" onClick={() => (window.location.hash = "#/reports")}>
        <Icon name="chart" size={16} className="text-flame" />
        {t("viewReportsCta")}
      </Btn>
    </div>
  );
}
